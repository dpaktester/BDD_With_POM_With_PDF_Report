/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */

package applicationhooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;

import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.TakesScreenshot;
import utilities.ConfigReader;
import io.cucumber.java.Scenario ;
import factory.DriverFactory;

public class AppHooks {
	private DriverFactory driverFactory;
	public static WebDriver driver;
	private ConfigReader configReader;
	//private SendAutomationReport sendReport;
	Properties prop;
	@Before(order =0)
	public  void getProperty(){
		configReader= new ConfigReader();
		prop= configReader.init_prop();
		
	}
	@Before(order=1)
	public void LaunchBrowser(){
		String browserName=prop.getProperty("browser");
		driverFactory = new DriverFactory();
		driver=driverFactory.init_Driver(browserName);
	}
	@After(order=0)
	public void quitBrowser(){
		driver.quit();
	}
	
	@After(order =1)
	public void tearDown (Scenario scenario){
		if (scenario.isFailed()){
			//take screen shot
			String screenshotName=scenario.getName().replaceAll(" ", "_");
			byte[] sourcePath =((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(sourcePath, "image/png", screenshotName);
//			sendReport.sendEmail();
			
		}	
		/*if(scenario.isFailed()==false) {
			sendReport.sendEmail();
		}*/
	}
}
