package stepdefinitions;

import static org.testng.Assert.assertTrue;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.util.List;
import java.util.Map;
import java.util.Properties;




import org.testng.Assert;

import pages.HomePage;
import pages.LoginPage;
import utilities.ConfigReader;
import factory.DriverFactory;

public class SmokeTestSteps {

	public static LoginPage loginPage;
	public static  HomePage homepage;
	public static Properties prop;
	

	@Then("user gets the fields of Home Page in PSM")
	public void user_gets_the_fields_of_accounts_section(DataTable expectedHomePageFieldTable) {
		
		List<String> expectedHomPageList=expectedHomePageFieldTable.asList();
		System.out.println("Expected List of Fields in Home Page: "+expectedHomPageList);
		List<String> actualHomPageList=homepage.getHomePageItemList();
		System.out.println("Actual List of Fields in Home Page: "+actualHomPageList);
		Assert.assertTrue(expectedHomPageList.equals(actualHomPageList));
	
	}

	@Then("the count of fields should be {int}")
	public void the_count_of_fields_should_be(Integer expectedHomePageCount) {
		Assert.assertTrue(homepage.getCountOfHomePage()==expectedHomePageCount);
	}

	@Then("Verify fields under Queues of PSM")
	public void verify_fields_under_queues_of_psm(DataTable queueDataTable) {
		List<String> expectedQueueList=queueDataTable.asList();
		System.out.println("Expected List of Fields under Queues: "+queueDataTable);
		List<String> actualQueueList=homepage.getQueueItemList();
		System.out.println("Actual List of Fields under Queues: "+actualQueueList);
		Assert.assertTrue(expectedQueueList.equals(actualQueueList));
	}

	@Then("Verify fields under Maintenance of PSM")
	public void verify_fields_under_maintenance_of_psm(DataTable maintenanceDataTable) {
		List<String> expectedMaintenanceList=maintenanceDataTable.asList();
		System.out.println("Expected List of Fields under Maintenance: "+maintenanceDataTable);
		List<String> actualMaintenanceList=homepage.getMaintenanceItemList();
		System.out.println("Actual List of Fields under Maintenance: "+actualMaintenanceList);
		assertTrue(actualMaintenanceList.containsAll(expectedMaintenanceList));
		//System.out.println("");
	}

	@Then("Verify fields under Dash Board")
	public void verify_fields_under_dash_board(DataTable dashBoardDataTable) {
		List<String> expectedDashBoardList=dashBoardDataTable.asList();
		System.out.println("Expected List of Fields under Dash Board: "+expectedDashBoardList);
		List<String> actualDashBoardList=homepage.getMaintenanceItemList();
		System.out.println("Actual List of Fields under Dash Board: "+actualDashBoardList);
		assertTrue(actualDashBoardList.containsAll(expectedDashBoardList));
	}

}
