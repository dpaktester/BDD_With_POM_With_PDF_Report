package stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import factory.DriverFactory;
import pages.LoginPage;
import utilities.ConfigReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	private DriverFactory driverFactory;
	public WebDriver driver;
	private ConfigReader configReader;
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	private static String title;

	
	@Given("user Enters URL of PSM Home")
	public void user_Enters_URL_of_PSM_Home() {
		loginPage.UserEntersPSMUrl();
	}

	@Given("user is on login page")
	public void user_is_on_login_page() {
		String title1 = loginPage.getTitle();
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		title = loginPage.getTitle();
		System.out.println("The login page title is :" + title);
	}

	@Then("the page title should be {string}")
	public void the_page_title_should_be(String expectedTitle) {

		Assert.assertTrue(title.contains(expectedTitle));
	}

	@Given("user Enters URL of ENS Home")
	public void user_enters_url_of_ens_home() {
		loginPage.UserEntersENSUrl();
	}

	@When("user enters username")
	public void user_enters_username() {
		// user=LoginPage.LoggedInUser;
		loginPage.enterUserId();
	}

	@When("user enetrs password")
	public void user_enetrs_password() throws Exception {
		loginPage.enterPassword();
	}

	@When("user enters username for ENSA_SUPPORT_USER")
	public void user_enters_username_for_ENSA_SUPPORT_USER() {
		loginPage.enterUserIdForENSA_SUPPORT_USER();
	}

	@When("user enetrs password for ENSA_SUPPORT_USER")
	public void user_enetrs_password_for_ENSA_SUPPORT_USER() throws Exception {
		loginPage.enterPasswordForENSA_SUPPORT_USER();
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() throws Exception {

		loginPage.clickSignin();
		Thread.sleep(5000);
	}

	@Then("user should see {string} as page header")
	public void user_should_see(String expectedHomePageTitle) throws Exception {
		loginPage.verifyHomePageTitle();
		Assert.assertTrue(LoginPage.hTitle.contains(expectedHomePageTitle));
	}

	@Then("user should see {string} as page header for ENS")
	public void user_should_see_as_page_header_for_ens(String expectedHomePageTitle1) throws Exception {
		loginPage.verifyHomePageTitleofENS();
		Assert.assertTrue(LoginPage.hTitle1.contains(expectedHomePageTitle1));
	}

}
