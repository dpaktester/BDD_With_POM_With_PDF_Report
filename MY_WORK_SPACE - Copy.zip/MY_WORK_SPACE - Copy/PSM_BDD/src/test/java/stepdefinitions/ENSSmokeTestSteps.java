/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */



package stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import pages.ENSSmokeTestPage;
import pages.HomePage;
import pages.LoginPage;
import utilities.ConfigReader;
import utilities.ElementUtil;
import factory.DriverFactory;

public class ENSSmokeTestSteps {
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	private ENSSmokeTestPage ensSmoke = new ENSSmokeTestPage(DriverFactory.getDriver());
	ElementUtil elementutil = new ElementUtil();
	private HomePage homepage;
	// private ENSSmokeTestPage ensSmoke;
	static Properties prop;
	private static ConfigReader configReader;// = new ConfigReader();

	@Before
	public static void LoadFile() {
		configReader = new ConfigReader();
		prop = configReader.init_prop();
	}

	@Given("user is on login page of ENS")
	public void user_is_on_login_page_of_ens() {
		String title2 = loginPage.getTitle();
	}

	@Then("user gets the fields of Home Page in ENS")
	public void user_gets_the_fields_of_home_page_in_ens() {
		// configReader= new ConfigReader();
		prop = configReader.init_prop();
		String[] ensAllModuleList = prop.getProperty("AllModulesOnENS").toString().split(",");
		// System.out.println("ensAllModuleList"+ensAllModuleList);
		List<String> list = Arrays.asList(ensAllModuleList);

		// List<String>
		// ensAllModuleList=Arrays.asList(prop.getProperty("AllModulesOnENS").toString().split(","));

		/*
		 * //System.out.println("Data Table:"
		 * +expectedHomePageFieldTableofENS.toString()); List<String>
		 * expectedHomPageListofENS=expectedHomePageFieldTableofENS.asList();
		 */
		// System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("Expected List of Fields in Home Page of ENS: " + list);
		// System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		List<String> actualHomPageListofENS = ensSmoke.getHomePageItemListofENS();
		System.out.println("Actual List of Fields in Home Page of ENS: " + actualHomPageListofENS);
		// Assert.assertTrue(expectedHomPageList.contains(actualHomPageList));
		Assert.assertTrue(list.equals(actualHomPageListofENS));

	}

	@Given("user is on Affliation page of ENS")
	public void user_is_on_affliation_page_of_ens() throws Exception {
		configReader = new ConfigReader();
		prop = configReader.init_prop();
		String Expected_Affiliation_Header = prop.getProperty("Affiliation_Header").toString();
		System.out.println("Expected_Affiliation_Header  _____" + Expected_Affiliation_Header);
		String Actual_Affiliation_Header = ensSmoke.getHeaderOfAffliationManagement();
		Assert.assertTrue(Expected_Affiliation_Header.equals(Actual_Affiliation_Header));

	}

	@When("user should click on affiliation management module button")
	public void user_should_click_on_affiliation_management_module_button() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("To be Clicked++++++++++++++++++++++++");
		ensSmoke.clickOnAffiliationLink();
		System.out.println("Clicked +++++++++++++++++++++++++");
	}

	@Then("user should get the fields of Affiliation management")
	public void user_should_get_the_fields_of_affiliation_management(io.cucumber.datatable.DataTable dataTable) {
		System.out.println("True passed");
	}

	@Then("user clicks on Queues of Affiliation management")
	public void user_clicks_on_Queues_of_Affiliation_management() {
		ensSmoke.clickOnQueuesofAffiliationLink();
	}

	@Then("user should get the fields under Queues of affiliation management")
	public void user_should_get_the_fields_under_queues_of_affiliation_management(
			io.cucumber.datatable.DataTable expecteItemsUnderQueues) {
		List<String> expectedListOfItemsUnderQueues = expecteItemsUnderQueues.asList();
		System.out.println(
				"Expected List of Items Under Queues of Affiliation Management: " + expectedListOfItemsUnderQueues);
		List<String> actualListOfItemsUnderQueues = ensSmoke.getQueuesItemListUnderAffiliation();
		System.out.println("List of Items Under Queues of Affiliation Management:: " + actualListOfItemsUnderQueues);
		Assert.assertTrue(expectedListOfItemsUnderQueues.equals(actualListOfItemsUnderQueues));
	}

	@Then("user clicks on Maintenance of Affiliation management")
	public void user_clicks_on_Maintenance_of_Affiliation_management() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ensSmoke.clickOnMaintenanceOfAffiliationLink();
	}

	@Then("user should get the fields under maintenance of affiliation management")
	public void user_should_get_the_fields_under_maintenance_of_affiliation_management(
			io.cucumber.datatable.DataTable expecteItemsUnderMaintenance) {
		List<String> expectedListOfItemsUnderMaintenance = expecteItemsUnderMaintenance.asList();
		System.out.println("Expected List of Items Under Maintenance of Affiliation Management: "
				+ expectedListOfItemsUnderMaintenance);
		List<String> actualListOfItemsUnderMaintenance = ensSmoke.getMaintenanceItemListUnderAffiliation();
		System.out.println(
				"List of Items Under maintenance of Affiliation Management:: " + actualListOfItemsUnderMaintenance);
		// Assert.assertTrue(expectedHomPageList.contains(actualHomPageList));
		Assert.assertTrue(expectedListOfItemsUnderMaintenance.equals(actualListOfItemsUnderMaintenance));
	}

	@When("user clicks on Submit Affiliation Request in Afiliation")
	public void user_clicks_on_submit_affiliation_request_in_afiliation() {
		ensSmoke.clickOnSubmitAffiliationBtnOfAffiliationManagement_AFMC();

	}

	@Then("user clisk on Manual Entry")
	public void user_clisk_on_manual_entry() {
		ensSmoke.click_On_Manual_Entry_Btn_of_Submit_Form_AFMC();

	}

	@Then("user clicks on Add Request Item")
	public void user_clicks_on_add_request_item() {
		ensSmoke.clickOnaddRequestBtnOfAffiliationManagement_AFMC();

	}

	@Then("user selects the request Type as Pharm Add in Affiliation")
	public void user_selects_the_request_type_as_pharm_add_in_affiliation() {
		ensSmoke.selectPharm_add_from_request_typeDropDown();

	}

	@Then("user eneters {int} in NCPDP Number in Affiliation")
	public void user_eneters_in_ncpdp_number_in_affiliation(Integer ncpdpNo) {
		ensSmoke.enter_Ncpdp_Number_Into_Request_Type_Box_pharmadd_in_AFMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.ncpdpNumberInputBox), "" + ncpdpNo + "");
		System.out.println("Entered Chain Code " + ncpdpNo + " in NCPDP Chain Code box of Affiliation Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user enters {string} as NCPDP Chain Code in Affiliation")
	public void user_enters_as_ncpdp_chain_code_in_affiliation(String ncpdpChainCode) {
		ensSmoke.enter_NCPDP_CHAIN_CODE_Number_Into_Request_Type_Box_pharmadd_in_AFMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.ncpdpChainCodeInputBox), "" + ncpdpChainCode + "");
		System.out.println(
				"Entered Chain Code " + ncpdpChainCode + " in NCPDP Chain Code box of Affiliation Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user enter {int} as payment center Number in Affiliation")
	public void user_enter_as_payment_center_number_in_affiliation(Integer paymentCenterNo) {
		ensSmoke.enter_Payment_Center_Number_Into_Request_Type_Box_pharmadd_in_AFMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.paymentCenterNoInputBox), "" + paymentCenterNo + "");
		System.out.println(
				"Entered Payment Center Number " + paymentCenterNo + " in text box of Affiliation Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user clicks on Add Entry button inside Affiliation")
	public void user_clicks_on_add_entry_button_inside_affiliation() {
		ensSmoke.clickOnaddEntrytBtnOfAffiliationManagement_AFMC();

	}

	@Then("user clicks on Submit Request button in Affiliation")
	public void user_clicks_on_submit_request_button_in_affiliation() {
		ensSmoke.clickOnSubmitRqstBtnOfAffiliationManagement_AFMC();

	}

	@Then("user cliks on OK in the alert after submiting the form")
	public void user_cliks_on_ok_in_the_alert_after_submiting_the_form() {
		ensSmoke.clickOnOkBtnAfterSubmitRqstBtnOfAffiliationManagement_AFMC();

	}

	@Then("user closes the message by clicking upon close in affiliation")
	public void user_closes_the_message_by_clicking_upon_close_in_affiliation() {
		ensSmoke.clickOncloseAlertBtnAfterSubmitRqstBtnOfAffiliationManagement_AFMC();
		

	}

	@Then("user clicks on PNA Review in Affiliation")
	public void user_clicks_on_pna_review_in_affiliation() throws Exception {

		ensSmoke.clickOnPNAReviewBtnOfAffiliationManagement_AFMC();
	}

	@Then("clicks on the Pencil icon of the created pharm add affiliation request")
	public void clicks_on_the_pencil_icon_of_the_created_pharm_add_affiliation_request() throws Exception {
		ensSmoke.entercreatedprojectandClickOnEditOFAffiliationManagement();
			
		
	}

	@Then("user clicks on Send to Configuration button inside affiliation")
	public void user_clicks_on_send_to_configuration_button_inside_affiliation() throws Exception {
		ensSmoke.click_On_send_to_configuration_btn_of_Created_Project_AFMC();
	}

	@Then("user clcks on OnHold of affiliation management")
	public void user_clcks_on_on_hold_of_affiliation_management() throws Exception {
		ensSmoke.clickOnHoldLink();

	}

	@Then("user clicks on the selection box of the created pharm add affiliation request")
	public void user_clicks_on_the_selection_box_of_the_created_pharm_add_affiliation_request() throws Exception {
		ensSmoke.selectTheProjectInOnHold();

	}

	@Then("user clicks on Group and Move to Configuration QC inside affiliation for the created pharm add request")
	public void user_clicks_on_group_and_move_to_configuration_qc_inside_affiliation_for_the_created_pharm_add_request() {
		ensSmoke.clickOnGroupandMoveToCongQC();

	}

	@Then("user enters the message to the Descripion Box after grp and config button in affiliation")
	public void user_enters_the_message_to_the_descripion_box_after_grp_and_config_button_in_affiliation() {
		ensSmoke.enterTheMessageafterGrpAndConfgQC();

	}

	@Then("user clicks on OK button in the description box of affiliation managament")
	public void user_clicks_on_ok_button_in_the_description_box_of_affiliation_managament() throws Exception{
		ensSmoke.clickOnOkBtnInsieOnHold();

	}

	@Then("user clicks twice on Configuration button to disapper the project")
	public void user_clicks_twice_on_configuration_button_to_disapper_the_project() {
		ensSmoke.clickOnConfigurationOfAffiliation();

	}

	@Then("user clicks on Configuration QC in Affiliation management")
	public void user_clicks_on_configuration_qc_in_affiliation_management() throws Exception {
		ensSmoke.clickOnConfigurationQCBtnOfAffiliation();

	}

	@Then("user clicks on the pencil icon of the created pharm add affiliation request")
	public void user_clicks_on_the_pencil_icon_of_th_ecreated_pharm_add_affiliation_request() {
		ensSmoke.clicksOnTheProjectinConfigQC_AFMC();

	}

	@Then("user selects the created phar add project in Affiliation Management")
	public void user_selects_the_created_phar_add_project_in_affiliation_management() throws Exception {
		ensSmoke.selectTheProjectinConfigQC_In_Pharm_Add_AFMC();

	}

	@Then("user clicks on withdraw project button inside Configuration QC of Affiliation Management")
	public void user_clicks_on_withdraw_project_button_inside_configuration_qc_of_affiliation_management() {
		ensSmoke.clicksOnWithdrawProjectinConfigQC_AFMC();

	}

	@Then("user selects the reason of pharm add withdrawal project in affiliaton management")
	public void user_selects_the_reason_of_pharm_add_withdrawal_project_in_affiliaton_management() {
		ensSmoke.selectReasonOfWithdrawalfromDropDownInConfigQA_AFMC();

	}

	@Then("user enters the withdrawal comment inside the comment box in Affiliation Management")
	public void user_enters_the_withdrawal_comment_inside_the_comment_box_in_affiliation_management() {
		ensSmoke.enterdIntoWithdrawalCommentBoxOfCreatedProjectinConfigQC_AFMC();

	}

	@Then("user clicks on OK button to withdraw pharm add project in Affiliation Management project")
	public void user_clicks_on_ok_button_to_withdraw_pharm_add_project_in_affiliation_management_project() {
		ensSmoke.clicksOnOkInWithdrawProjectinConfigQC_AFMC();

	}

	@Then("user selects the request Type as Pharm Term in Affiliation")
	public void user_selects_the_request_Type_as_Pharm_Term_in_Affiliation() {
		ensSmoke.selectPharm_term_from_request_typeDropDown_AFMC();
	}

	@Then("user eneters {int} in NCPDP Number field in Affiliation")
	public void user_eneters_in_ncpdp_number_field_in_affiliation(Integer ncpdpNo2) {
		ensSmoke.enter_Ncpdp_Number_Into_Request_Type_Box_pharmadd_in_AFMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.ncpdpNumberInputBox), "" + ncpdpNo2 + "");
		System.out.println("Entered Chain Code " + ncpdpNo2 + " in NCPDP Chain Code box of Affiliation Management ");
		System.out.println("---------------------------------------------------");
	}
	@Then("user selects the created pha term project in Affiliation Management")
	public void user_selects_the_created_pha_terms_project_in_Affiliation_Management()throws Exception {
		ensSmoke.selectTheProjectinConfigQC_In_Pharm_Term_AFMC();
	}
	@Then("user should select the term reason")
	public void user_should_select_the_term_reason() {
		ensSmoke.select_Term_Reason_DropDown_AFMC();
	}

	@Then("clicks on the Pencil icon of the created pharm term affiliation request")
	public void clicks_on_the_Pencil_icon_of_the_created_pharm_term_affiliation_request() throws Exception {
		ensSmoke.entercreatedprojectToBeTermedandClickOnEditOFAffiliationManagement();
	}

	@Then("user clicks on the selection box of the created pharm term affiliation request")
	public void clicks_on_the_selection_box_of_the_created_pharm_term_affiliation_request() throws Exception {
		ensSmoke.selectThePharmTermProjectInOnHold();
	}

	@Then("user clicks on Send to Configuration button inside affiliation for pharmacy Term")
	public void user_clicks_on_Send_to_Configuration_button_inside_affiliation_for_pharmacy_Term() throws Exception {
		ensSmoke.click_On_send_to_configuration_btn_of_Created_Project_For_Pharm_Term_AFMC();
	}

	@Given("user clicks on contract management button")
	public void user_clicks_on_contract_management_button() {
		ensSmoke.clickOnContractManagementLink();
	}

	@Then("user should get the fields of contract management")
	public void user_should_get_the_fields_of_contract_management(io.cucumber.datatable.DataTable dataTable) {
		configReader = new ConfigReader();
		prop = configReader.init_prop();
		String[] listOfItemsInContractManagement = prop.getProperty("CommonFieldsofAllModules").toString().split(",");
		List<String> list = Arrays.asList(listOfItemsInContractManagement);
		List<String> actualListOfItemsInContractManagement = ensSmoke.getFieldsunderContractManagement();
		System.out.println("True passed");
		Assert.assertTrue(list.equals(actualListOfItemsInContractManagement));
		System.out.println("True passed");

	}

	@When("user clicks on Queues of Contract Management")
	public void user_clicks_on_queues_of_contract_management() {
		ensSmoke.clickOnQueueOfContractManagementLink();
	}

	@Then("user should click on My Tasks of Contract management under Queues")
	public void user_should_click_on_My_Tasks_of_Contract_management_under_Queues() {
		ensSmoke.clickOnMyTaskOfContractManagementLink();
	}

	@Then("user should see {string} as the header of Contract management")
	public void user_should_see_the_header_as_My_Tasks_Contract(String header) throws Exception {
		ensSmoke.verifyContractManagementPageTitle();
		System.out.println("Expected ContractManageMentTitle :: " + header);
		Assert.assertTrue(ensSmoke.ContractManageMentTitle.contains(header));
	}

	@Then("user should verify fields under Queues of contract managemet")
	public void user_should_verify_fields_under_Queues_of_contract_managemet(
			io.cucumber.datatable.DataTable expecteItemsUnderQueuesOfContractManagement) {
		List<String> expectedListOfItemsUnderQueuesOfContractManagement = expecteItemsUnderQueuesOfContractManagement
				.asList();
		System.out.println("Expected List of Items Under Queues of Contract Management: "
				+ expectedListOfItemsUnderQueuesOfContractManagement);
		List<String> actualListOfItemsUnderQueuesOfContractManagement = ensSmoke
				.getQueuesItemListUnderContractManagement();
		System.out.println("Actual List of Items Under Under Queues of Contract Management:: "
				+ actualListOfItemsUnderQueuesOfContractManagement);
		// Assert.assertTrue(expectedHomPageList.contains(actualHomPageList));
		Assert.assertTrue(expectedListOfItemsUnderQueuesOfContractManagement
				.equals(actualListOfItemsUnderQueuesOfContractManagement));
	}

	@Then("user should click on Manintenance of Contract management")
	public void user_should_click_on_Manintenance_of_Contract_management() throws Exception {
		ensSmoke.clickOnMaintenanceLinkUnderContractManagement();

	}

	@Then("user should verify the fields under Maintenance of Contract management")
	public void user_should_verify_the_fields_under_Maintenance_of_Contract_management(
			io.cucumber.datatable.DataTable expecteItemsUnderMaintenanceOfContractManagement) {
		List<String> expectedListOfItemsUnderMaintOfContractManagement = expecteItemsUnderMaintenanceOfContractManagement
				.asList();
		System.out.println("Expected List of Items Under Maintenance of Contract Management: "
				+ expectedListOfItemsUnderMaintOfContractManagement);
		List<String> actualListOfItemsUnderMaintOfContractManagement = ensSmoke
				.getMaintenanceItemListUnderContractManagement();
		System.out.println("Actual List of Items Under Under Maintenance of Contract Management:: "
				+ actualListOfItemsUnderMaintOfContractManagement);
		// Assert.assertTrue(expectedHomPageList.contains(actualHomPageList));
		Assert.assertTrue(expectedListOfItemsUnderMaintOfContractManagement
				.equals(actualListOfItemsUnderMaintOfContractManagement));

	}

	@When("user clicks on Client Contract")
	public void user_clicks_on_client_contract() {
		ensSmoke.clickOnManageClientContractBtnOfContractManagementLink();
	}

	@Then("user sees the Title of client contract as {string}")
	public void user_sees_the_header_of_client_contract_as(String title1) throws Exception {
		System.out.println("Deepak");

		// ensSmoke.verifytPageTitleOfClientContractManagement();
		// Assert.assertTrue(ensSmoke.title.contains(title1));
	}

	@Then("user should select Hq List Code from dropdown")
	public void user_should_select_Hq_List_Code_from_dropdown() throws Exception {
		ensSmoke.selectHqListCodefromDropDown();
	}

	@Then("user should enter the hqlist code in the search box of contract management")
	public void user_should_enter_the_hqlist_code_in_the_search_box_of_contract_management() {
		ensSmoke.enterHqCodeIntoinputBoxOFContractManagement();
	}

	@Then("user should click on search button of contract management")
	public void user_should_click_on_search_button_of_contract_management() {
		ensSmoke.clickOnSearchBtnOfContractManagementLink();
	}

	@Then("user should click on eye button to view the details of hq list code")
	public void user_should_click_on_eye_button_to_view_the_details_of_hq_list_code() throws Exception {
		ensSmoke.clickOneyeBtntoViewHqListOfContractManagement();
	}

	@Then("user should click on Create project of Contract Management")
	public void user_should_click_on_Create_project_of_Contract_Management() {
		ensSmoke.clickOCreateProjectOfContractManagement();
	}

	@Then("user should select client contract management project of contract management")
	public void user_should_select_client_contract_management_project() {
		ensSmoke.clickOncontractManagementProjectOfContractManagement();
	}

	@Then("user should click on continue button to create a maintaiance project")
	public void user_should_click_on_continue_button_to_create_a_maintaiance_project() {
		ensSmoke.clickOnContinueBtnOfContractManagementforMaintainanceProjectCreation();
	}


	@Then("user should Click on button beside All to add everything in Service Type")
	public void user_should_Click_on_button_beside_All_to_add_everything_in_Service_Type() throws Exception {
		ensSmoke.clickOnAddNewAllServiceType();
	}

	@Then("user should select Choice90 in Service Type")
	public void user_should_select_Choice90_in_Service_Type() throws Exception {
		ensSmoke.selectChoice90fromServiceTypeDropDown();
	}

	@Then("user should click on copy button beside All to add everything in client rate")
	public void user_should_click_on_copy_button_beside_All_to_add_everything_in_client_rate() throws Exception {
		ensSmoke.clickOnAddNewAllServiceTypeInClientRateManagement();
	}

	@Then("user select choice90 as service type in client rate")
	public void user_select_choice90_as_service_type_in_client_rate() throws Exception {
		ensSmoke.selectChoice90fromServiceTypeDropDownInClientRate();
		
	}

	@Then("user should delete the start date and enter todays date in client contract rate")
	public void user_should_delete_the_start_date_and_enter_todays_date_in_client_contract_rate() throws Exception {
		ensSmoke.enterStartDateInClientRate();
	}

	@Then("user should delete the end date and enter any date except todays date in client contract rate")
	public void user_should_delete_the_end_date_and_enter_any_date_except_todays_date_in_client_contract_rate()
			throws Exception {
		ensSmoke.enterEndDateInClientRate();
	}

	@Then("user should click on Save Progress button in contract management maintenance Project")
	public void user_should_click_on_Save_Progress_button_in_contract_management_maintenance_Project()
			throws Exception {
		ensSmoke.clickonSaveButtonContractManagement();
	}

	@When("user clicks on send to contract QA in client contract manageent maintenance project")
	public void user_clicks_on_send_to_contract_QA_in_client_contract_manageent_maintenance_project() throws Exception {
		ensSmoke.clickonSendToContractQAOfContractManagement();
	}

	@Then("user clicks on Conract QA in Contract Management")
	public void user_clicks_on_Conract_QA_in_Contract_Management() throws Exception {
		ensSmoke.clickOnContractQABtnOfContractManagement();
	}

	@Then("user clicks on the pencil icon of created project in contract QA")
	public void user_clicks_on_the_pencil_icon_of_created_project_in_contract_QA() {
		ensSmoke.click_On_Edit_Icon_of_Created_Project_on_contract_QA_CMMC();
	}

	@Then("user clicks on send back to Contract Analyst button")
	public void user_clicks_on_send_back_to_Contract_Analyst_button() {
		ensSmoke.click_On_send_back_to_analyst_queue_of_Created_Project_CMMC();
	}

	@Then("user clicks on contract analyst on the main page")
	public void user_clicks_on_contract_analyst_on_the_main_page() throws Exception {
		ensSmoke.clickOnContractAnalystBtnOfContractManagement();
	}

	@Then("user clicks on edit icon of the sent project on contract analyst")
	public void user_clicks_on_edit_icon_of_the_sent_project_on_contract_analyst() {
		ensSmoke.click_On_Edit_Icon_of_Created_Project_insideContract_Analyst_CMMC();
	}

	@Then("user should click on withdraw button inside maintainance project creation")
	public void user_should_click_on_withdraw_button_inside_maintainance_project_creation() {
		ensSmoke.clickOnWirhdrawBtnOfMaintProjCreation_CMMC();
	}

	@Then("user should enter the comment to withdraw the client contract maintaiance project")
	public void user_should_enter_the_comment_to_withdraw_the_client_contract_maintaiance_project() {
		ensSmoke.enterWithdrawalCommenttOFContractManagement_CMMC();
	}

	@Then("user should click on ok to withdraw the client contract project from creation")
	public void user_should_click_on_ok_to_withdraw_the_client_contract_project_from_creation() throws Exception {
		ensSmoke.clickOnOkBtnOfWithdrawalOfContractmanagement_CMMC();
	}

	@When("user should click on Rate management module button")
	public void user_should_click_on_rate_management_module_button() {
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("To be Clicked on Rate Managament++++++++++++++++++++++++");
		ensSmoke.clickOnRateManagementLink();
		System.out.println("Clicked  on Rate Management +++++++++++++++++++++++++");
	}

	@Then("user should get the fields of Rate management")
	public void user_should_get_the_fields_of_rate_management(io.cucumber.datatable.DataTable dataTable) {
		
		System.out.println("True passed");
	}

	@Then("user clicks on Queues of Rate management")
	public void user_clicks_on_queues_of_rate_management() {
		ensSmoke.clickOnQueuesofRateManagementLink();

	}

	@Then("user should get the fields under Queues of Rate management")
	public void user_should_get_the_fields_under_queues_of_rate_management(
			io.cucumber.datatable.DataTable expectedListOfItemsUnderQueuesOfRateManagement) {
		List<String> expectedListOfItemsUnderQueuesOfRateMngmnt = expectedListOfItemsUnderQueuesOfRateManagement
				.asList();
		System.out.println("Expected List of Items Under Queues of Rate Management: "
				+ expectedListOfItemsUnderQueuesOfRateMngmnt);
		List<String> actualListOfItemsUnderQueuesOfRateMngmnt = ensSmoke.getQueuesItemListUnderRateManagement();
		System.out.println(
				"List of Items Under Queues of Affiliation Management:: " + actualListOfItemsUnderQueuesOfRateMngmnt);
		Assert.assertTrue(expectedListOfItemsUnderQueuesOfRateMngmnt.equals(actualListOfItemsUnderQueuesOfRateMngmnt));
	}

	@Then("user clicks on Maintenance of Rate management")
	public void user_clicks_on_maintenance_of_rate_management() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		ensSmoke.clickOnMaintenanceOfRateManagementLink();

	}

	@Then("user should get the fields under maintenance of Rate management")
	public void user_should_get_the_fields_under_maintenance_of_rate_management(
			io.cucumber.datatable.DataTable expecteItemsUnderMaintenanceOfRateManagement) {
		List<String> expectedListOfItemsUnderMaintenanceOfRateMngmnt = expecteItemsUnderMaintenanceOfRateManagement
				.asList();
		System.out.println("Expected List of Items Under Maintenance of Affiliation Management: "
				+ expectedListOfItemsUnderMaintenanceOfRateMngmnt);
		List<String> actualListOfItemsUnderMaintenanceofRateMngmnt = ensSmoke
				.getMaintenanceItemListUnderRateManagement();
		System.out.println("List of Items Under maintenance of Affiliation Management:: "
				+ actualListOfItemsUnderMaintenanceofRateMngmnt);
		Assert.assertTrue(
				expectedListOfItemsUnderMaintenanceOfRateMngmnt.equals(actualListOfItemsUnderMaintenanceofRateMngmnt));
	}

	@Then("user should click on Manage Pharmacy List of Rate Management")
	public void user_should_click_on_manage_pharmacy_list_of_rate_management() {
		ensSmoke.clickOnManagePharmacyListBtnOfRateManagement_RMC();
	}

	@Then("user should enter Pharmacy List Name as {string} and then click outside while creating Pharmacy List in Rate Managament")
	public void user_should_enter_pharmacy_list_name_as_and_then_click_outside_while_creating_pharmacy_list_in_rate_managament(
			String pharmacyListName) {
		ensSmoke.enter_Pharmacy_List_Name_Into_PLN_Box_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.pharmacyNameListTextBox), "" + pharmacyListName + "");
		System.out.println("Entered Pharmacy List Name " + pharmacyListName
				+ " in Pharmacy List Name Text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user entered project description as {string} while creating Pharmacy List in Rate Managament")
	public void user_entered_project_description_as_while_creating_pharmacy_list_in_rate_managament(
			String descriptionBoxOfPLCreation) {
		ensSmoke.enter_Description_Name_Into_PLN_Box_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.descriptionBoxOfPharmacyListCreation),
				"" + descriptionBoxOfPLCreation + "");
		System.out.println("Entered Description as " + descriptionBoxOfPLCreation
				+ " in the description box while creating Pharmacy List in Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user clicked on Create Project while creating Pharmacy List in Rate Managament")
	public void user_clicked_on_create_project_while_creating_pharmacy_list_in_rate_managament()throws Exception {
		ensSmoke.clickOnCreateProjectBtn_PharmacyList_RMC();
	}

	@Then("user entered {string} as career HQ Code while creating Pharmacy List in Rate Managament")
	public void user_entered_as_career_hq_code_while_creating_pharmacy_list_in_rate_managament(String HQCodeTextBox) {
		ensSmoke.enter_HQList_While_Creating_Pharmacy_List_Box_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.HqListCodetextBox_RMC), "" + HQCodeTextBox + "");
		System.out.println("Entered HQ List as " + HQCodeTextBox
				+ " in the HQ List box while creating Pharmacy List in Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user entered NABP No as {int}  while creating Pharmacy List in Rate Managament and click out side")
	public void user_entered_nabp_no_as_while_creating_pharmacy_list_in_rate_managament_and_click_out_side(
			Integer NABPNo) {
		try {
			ensSmoke.enter_NABP_No_RMC();
		} catch (Exception e) {
			e.printStackTrace();
		}
		ensSmoke.driver.findElement(ensSmoke.NABP_NO_Click).click();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.NABPNo_RMC), "" + NABPNo + "");
		System.out.println("Entered NABP No as " + NABPNo
				+ " in the NABP No Text box while creating Pharmacy List in Rate Management ");
		ensSmoke.driver.findElement(ensSmoke.HqListCodetextBox_RMC).click();
		System.out.println("Activated the Add Nabp No by clicking on HQ Code");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should click on Add button for the NABP to be added and copy the data for verification")
	public void user_should_click_on_add_button_for_the_nabp_to_be_added_and_copy_the_data_for_verification()
			throws Exception {
		ensSmoke.clickOnAddBtnWhileCreatingPL_RMC();
	}

	@Then("user should click on click on send to configuration QA button while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_click_on_send_to_configuration_qa_button_while_creating_pharmacy_list_in_rate_managament()
			throws Exception {
		ensSmoke.clickOnSendToConfigurationBtnOfRateManagement_RMC();
	}

	@When("user should click on configuration QA while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_configuration_qa_while_creating_pharmacy_list_in_rate_managament()
			throws Exception {
		ensSmoke.clickOnConfigurationQABtnOf_RMC();
	}

	@Then("user should click on the created the project while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_the_created_the_project_while_creating_pharmacy_list_in_rate_managament()
			throws Exception {
		ensSmoke.clickedOnEditIconOnConfgQC_RMC();
	}

	@Then("user should verify the data with the created data while creating Pharmacy List in Rate Managament")
	public void user_should_verify_the_data_with_the_created_data_while_creating_pharmacy_list_in_rate_managament() {
		System.out.println("");
	}

	@Then("user should click on send back to configuration analyst while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_send_back_to_configuration_analyst_while_creating_pharmacy_list_in_rate_managament()
			throws Exception {
		ensSmoke.clickedOnSendToConfigAnalyst_RMC();
	}

	@Then("user should click on Configuration Analyst button while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_Configuration_Analyst_button_while_creating_Pharmacy_List_in_Rate_Managament()
			throws Exception {
		ensSmoke.clickOnConfigurationAnalyst_RMC();
	}

	@Then("user should search the created project and click on it while creating Pharmacy List in Rate Managament")
	public void user_should_search_the_created_project_and_click_on_it_while_creating_pharmacy_list_in_rate_managament()
			throws Exception {
		ensSmoke.clickedOnEditIconOnConfgQC_RMC();
		System.out.println("Clicked on the created project of Configuration Analyst of Rate Managament");

	}

	@Then("user should click on withdraw button while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_withdraw_button_while_creating_pharmacy_list_in_rate_managament() {
		ensSmoke.clickOnWithDrawConfigurationAnalyst_RMC();

	}

	@Then("user should enter the comments while creating Pharmacy List in Rate Managament")
	public void user_should_enter_the_comments_while_creating_pharmacy_list_in_rate_managament() {
		ensSmoke.enterWithdrawalCommentOnConfigAnalyst_RMC();

	}

	@Then("user should click on ok while creating Pharmacy List in Rate Managament")
	public void user_should_click_on_ok_while_creating_pharmacy_list_in_rate_managament() {
		ensSmoke.clickOnOkBtnOfWithDrawConfigurationAnalyst_RMC();

	}

	@Then("user should click on Manage Building Block of Rate Management")
	public void user_should_click_on_manage_building_block_of_rate_management() {
		ensSmoke.clickOnManageBuildingblocksBtnOfRateManagement_RMC();

	}

	@Then("user should enter description text box as {string} while creating BB in Rate Managament")
	public void user_should_enter_description_text_box_as_while_creating_bb_in_rate_managament(String description) {
		ensSmoke.enter_Description_Name_Into_Description_Box_While_Creating_BB_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.descriptionBoxOfPharmacyListCreation),
				"" + description + "");
		System.out.println("Entered Description " + description
				+ " in the Description box while creating Building Block in Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should click on Create Project while creating BB in Rate Managament")
	public void user_should_click_on_create_project_while_creating_bb_in_rate_managament()throws Exception {
		ensSmoke.clickOnCreateProjectLink_RMC();

	}

	@Then("user should enter the Building Block Name as {string} while creating BB in Rate Managament")
	public void user_should_enter_the_building_block_name_as_while_creating_bb_in_rate_managament(String BBName) throws Exception {
		LocalDate startDate = LocalDate.now();
		elementutil.RandomNumber();
		try {
			ensSmoke.enter_BBName_RMC();
		} catch (Exception e) {
			e.printStackTrace();
		}
		ensSmoke.driver.findElement(ensSmoke.clickOnBBName_RMC).click();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.enterOnBBName_RMC), "" + BBName + elementutil.ranNo+startDate+"");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("Entered Building Block Name " + BBName
				+ " in the Building Block Text box while creating Building Block in Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should select R from the services dropdown while creating BB in Rate Managament")
	public void user_should_select_r_from_the_services_dropdown_while_creating_bb_in_rate_managament()
			throws Exception {
		ensSmoke.selectRfromServiceTypeDropDown_RMC();

	}

	@Then("user should select ABB from the ABB\\/CBB drop down while creating BB in Rate Managament")
	public void user_should_select_abb_from_the_abb_cbb_drop_down_while_creating_bb_in_rate_managament()
			throws Exception {
		ensSmoke.selectABBfromABB_CBB_DropDown_RMC();

	}

	@Then("user should select Building Block Type as Aggregate while creating BB in Rate Managament")
	public void user_should_select_building_block_type_as_aggregate_while_creating_bb_in_rate_managament()
			throws Exception {
		ensSmoke.selectAggregate_From_Building_Block_Type_DropDown_RMC();

	}

	@Then("user should select LOB as Commercial while creating BB in Rate Managament")
	public void user_should_select_lob_as_commercial_while_creating_bb_in_rate_managament() throws Exception {
		ensSmoke.selectCommercial_From_LOb_DropDown_RMC();

	}

	@Then("user should select Pharmacy Type as NCPDP while creating BB in Rate Managament")
	public void user_should_select_pharmacy_type_as_ncpdp_while_creating_bb_in_rate_managament() throws Exception {
		ensSmoke.selectNCPDP_From_PharmacyType_DropDown_RMC();

	}

	@Then("user should enter {int} in pharmacy identifier while creating BB in Rate Managament and click outside")
	public void user_should_enter_in_pharmacy_identifier_while_creating_bb_in_rate_managament_and_click_outside(
			Integer pharmacyTypeNo) throws Exception {
		ensSmoke.enterPharmacyType_RMC();
		// ensSmoke.driver.findElement(ensSmoke.pharmacy_identifier_Click_RMC).click();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.pharmacy_identifier_input_RMC),
				"" + pharmacyTypeNo + "");
		System.out.println(
				"Entered pharmacy Type as " + pharmacyTypeNo + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	
		ensSmoke.clickOutside_RMC();
	}

	@Then("user should click on add button in action while creating BB in Rate Managament")
	public void user_should_click_on_add_button_in_action_while_creating_bb_in_rate_managament() throws Exception {
		ensSmoke.clickOnAddBtnAddingBuildingBlock_RMC();

	}

	@When("user should click on save button while creating BB in Rate Managament")
	public void user_should_click_on_save_button_while_creating_bb_in_rate_managament() {

		ensSmoke.clickOnSaveProgressButton_RMC();
	}

	@Then("user should check the for the correct data is saved or not in while creating BB Rate Managament")
	public void user_should_check_the_for_the_correct_data_is_saved_or_not_in_while_creating_bb_rate_managament() {
		System.out.println("Deepak");

	}

	@Then("user should click on send to pricing Approver button while creating BB in Rate Managament")
	public void user_should_click_on_send_to_pricing_approver_button_while_creating_bb_in_rate_managament() {

		ensSmoke.clickOnSendToPricingAnalystButton_RMC();
	}

	@Then("user should click on Pricing Analyst Approver button while creating BB in Rate Managament")
	public void user_should_click_on_pricing_analyst_approver_button_while_creating_bb_in_rate_managament()throws Exception {

		ensSmoke.clickOnPricingAnalystApprover_RMC();
	}

	@Then("user should enter the project description in Pricing Analyst Approver  and click on the edit icon of created proejct while creating BB in Rate Managament")
	public void user_should_enter_the_project_description_in_pricing_analyst_approver_and_click_on_the_edit_icon_of_created_proejct_while_creating_bb_in_rate_managament()
			throws Exception {
		ensSmoke.clickedOnEditIconOnPricingAnalystApprover_RMC();

	}

	@Then("user should click on Send Back to Pricing Analyst button while creating BB in Rate Managament")
	public void user_should_click_on_send_back_to_pricing_analyst_button_while_creating_bb_in_rate_managament() {
		ensSmoke.clickOnSendBackToPricingAnalystButton_RMC();

	}

	@Then("user should click on Pricing Analyst button while creating BB in Rate Managament")
	public void user_should_click_on_pricing_analyst_button_while_creating_bb_in_rate_managament() throws Exception {
		ensSmoke.clickOnPricingAnalyst_RMC();

	}

	@Then("user should enter the project description in Pricing Analyst and click on the eidt icon of created project while creating BB in Rate Managament")
	public void user_should_enter_the_project_description_in_pricing_analyst_and_click_on_the_eidt_icon_of_created_project_while_creating_bb_in_rate_managament()
			throws Exception {
		ensSmoke.clickedOnEditIconOnPricingAnalystApprover_RMC();

	}

	@Then("user should click on withdraw button of project while creating BB in Rate Managament")
	public void user_should_click_on_withdraw_button_of_project_while_creating_bb_in_rate_managament() {

		ensSmoke.clickOnWithDrawConfigurationAnalyst_RMC();
	}

	@Then("user should enter the comment as {string} whiling withdraing the BB Creation project in Rate Managament")
	public void user_should_enter_the_comment_as_whiling_withdraing_the_bb_creation_project_in_rate_managament(
			String string) {
		ensSmoke.enterWithdrawalCommentOnConfigAnalyst_RMC();

	}

	@Then("user should click on Ok whiling withdraing the BB Creation project")
	public void user_should_click_on_ok_whiling_withdraing_the_bb_creation_project() {
		ensSmoke.clickOnOkBtnOfWithDrawConfigurationAnalyst_RMC();

	}

	@Then("user should click on Manage CNP of Rate Management")
	public void user_should_click_on_Manage_CNP_of_Rate_Management() {
		ensSmoke.clickOnManageCNPBtnOfRateManagement_RMC();
	}

	@Then("user should select HQ List whie creating CNP Project in Rate Management")
	public void user_should_select_hq_list_whie_creating_cnp_project_in_rate_management() {
		ensSmoke.selecthqList_from_request_typeDropDown();

	}

	@Then("user should enter {string} as Project Name while creating CNP Project in Rate Management")
	public void user_enter_ProjectName_Into_Search_Box_CNp_Creation_in_RMC(String projectName) {
		ensSmoke.enter_ProjectName_Into_Search_Box_CNP_Creation_in_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.projectname_CNP_Creation_RMC), "" + projectName + "");
		System.out.println("Entered project name " + projectName + " in text box of CNP Creation In Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should click on search button while creating CNP Project in Rate Management")
	public void user_should_click_on_search_button_while_creating_cnp_project_in_rate_management() {

		ensSmoke.clickOnSearchBtnInCNPCreation_RMC();
	}

	@Then("user should click on eye button after clicking on search button while creating CNP Project in Rate Management")
	public void user_should_click_on_eye_button_after_clicking_on_search_button_while_creating_cnp_project_in_rate_management()
			throws Exception {
		ensSmoke.clickOneyeBtntoViewCNP_RMC();

	}

	@Then("user should click on create project button whlie creating CNP Project in Rate Management")
	public void user_should_click_on_create_project_button_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnCreateProjectButto_CNP_RMC();

	}

	@Then("user should select service type as retail whlie creating CNP Project in Rate Management")
	public void user_should_select_service_type_as_retail_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnRetailOnServiceTypeSelection_CNP_RMC();

	}

	@Then("user should enter into description box as {string} whlie creating CNP Project in Rate Management")
	public void user_should_enter_into_comment_box_as_whlie_creating_cnp_project_in_rate_management(
			String descriptionCNP) {
		ensSmoke.enter_ProjectName_Into_Search_Box_CNP_Creation_in_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.description_CNP_RMC), "" + descriptionCNP + "");
		System.out.println("Entered Description " + descriptionCNP
				+ " in description text box of CNP Creation In Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should click on continue button whlie creating CNP Project in Rate Management")
	public void user_should_click_on_continue_button_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnContinue_CNP_RMC();

	}

	@Then("user should enter {int} in brand discount under client rate whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_brand_discount_under_client_rate_while_creating_CNP_peoject_in_Rate_Management(
			Integer BrandDiscount) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.brandDiscountTextBox_Client_Rate_CNP_RMC),
				"" + BrandDiscount + "");
		System.out.println(
				"Entered pharmacy Type as " + BrandDiscount + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user should enter {int} in Brand Fill under client rate whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_brand_fill_under_client_rate_while_creating_CNP_peoject_in_Rate_Management(
			Integer BrandFill) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.brandFillFeeTextBox_Client_Rate_CNP_RMC),
				"" + BrandFill + "");
		System.out.println("Entered pharmacy Type as " + BrandFill + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user should enter {int} in Generic Discount under Client rate whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_generic_discount_under_client_rate_while_creating_CNP_peoject_in_Rate_Management(
			Integer genericDiscount) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.genericDiscountTextBox_Client_Rate_CNP_RMC),
				"" + genericDiscount + "");
		System.out.println(
				"Entered pharmacy Type as " + genericDiscount + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user should enter {int} in Generic Fee under cilent rate whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_generic_fee_under_client_rate_while_creating_CNP_peoject_in_Rate_Management(
			Integer genericFee) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.genericFillFeeTextBox_Client_Rate_CNP_RMC),
				"" + genericFee + "");
		System.out
				.println("Entered pharmacy Type as " + genericFee + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user should enter {string} as price code under client rate whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_brand_price_code_under_client_rate_while_creating_CNP_peoject_in_Rate_Management(
			String priceCode) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.priceCodeTestBox_Client_Rate_CNP_RMC),
				"" + priceCode + "");
		System.out.println("Entered pharmacy Type as " + priceCode + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");
	}

	@Then("user should select the BB Type as Aggregate whlie creating CNP Project in Rate Management")
	public void user_should_select_the_bb_type_as_aggregate_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.selectAggregateFromBBTypeDropDown_RMC();

	}

	@Then("user should select any BB name from the dropdown whlie creating CNP Project in Rate Management")
	public void user_should_select_any_bb_name_from_the_dropdown_whlie_creating_cnp_project_in_rate_management()
			throws Exception {
		ensSmoke.selectNameFromBBNameDropDown_RMC();

	}

	@Then("user should click on add button whlie creating CNP Project in Rate Management")
	public void user_should_click_on_add_button_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnAddBtn_CNP_RMC();

	}

	@Then("user should enter {int} in Brand Discount whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_brand_discount_whlie_creating_cnp_project_in_rate_management(Integer BrandDiscount)
			throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.brandDicountTextBox_CNP_RMC), "" + BrandDiscount + "");
		System.out.println(
				"Entered pharmacy Type as " + BrandDiscount + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should enter {int} in Brand Fill whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_brand_fill_whlie_creating_cnp_project_in_rate_management(Integer BrandFill)
			throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.brandFellFeeTextBox_CNP_RMC), "" + BrandFill + "");
		System.out.println("Entered pharmacy Type as " + BrandFill + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should enter {int} in Generic Discount whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_generic_discount_whlie_creating_cnp_project_in_rate_management(
			Integer genericDiscount) throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.genericDiscountTextBox_CNP_RMC),
				"" + genericDiscount + "");
		System.out.println(
				"Entered pharmacy Type as " + genericDiscount + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should enter {int} in Generic Fee whlie creating CNP Project in Rate Management")
	public void user_should_enter_in_generic_fee_whlie_creating_cnp_project_in_rate_management(Integer genericFee)
			throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.genericFillFeeTextBox_CNP_RMC), "" + genericFee + "");
		System.out
				.println("Entered pharmacy Type as " + genericFee + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should enter {string} as price code whlie creating CNP Project in Rate Management")
	public void user_should_enter_as_price_code_whlie_creating_cnp_project_in_rate_management(String priceCode)
			throws Exception {
		ensSmoke.enterBrandDiscount_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.priceCodetextBox_CNP_RMC), "" + priceCode + "");
		System.out.println("Entered pharmacy Type as " + priceCode + "  in Pharmacy Type text box of Rate Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should click on save progress whlie creating CNP Project in Rate Management")
	public void user_should_clickon_save_progress_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnSaveProgressOfRateManagement_RMC();

	}

	@Then("user should click on send to pricing approver whlie creating CNP Project in Rate Management")
	public void user_should_click_on_send_to_pricing_approver_whlie_creating_cnp_project_in_rate_management() {
		ensSmoke.clickOnSendToPricingApproverBtn_CNP_RMC();

	}

	@When("user clicks on Pricing anaylyst Approver whlie creating CNP Project in Rate Management")
	public void user_clicks_on_pricing_anaylyst_approver_whlie_creating_cnp_project_in_rate_management()
			throws Exception {
		ensSmoke.clickOnPricingAnlystApprover_CNP_RMC();

	}

	@Then("user should enter the project descrition whlie creating CNP Project in Rate Management in Pricing Analyst Approver and click on the pencil icon")
	public void user_should_enter_the_project_descrition_whlie_creating_cnp_project_in_rate_management_in_pricing_analyst_approver()
			throws Exception {
		ensSmoke.clickedOnEditIconOnPricingAnalystApprover_CNP_RMC();

	}

	@Then("user should click on send to configuration analyst button whlie creating CNP Project in Rate Management")
	public void user_should_click_on_send_to_configuration_analyst_button_whlie_creating_cnp_project_in_rate_management() {

		ensSmoke.clickOnSendToConfigurationAnalystApproverBtn_CNP_RMC();
	}

	@When("user clicks on Configuration Analyst whlie creating CNP Project in Rate Management")
	public void user_clicks_on_configuration_analyst_whlie_creating_cnp_project_in_rate_management() throws Exception {
		ensSmoke.clickOnConfigurationAnalyst_Btn_CNP_RMC();

	}

	@Then("user user should enter the description whlie creating CNP Project in Rate Management in Configuration Analyst  and click on the pencil icon")
	public void user_user_should_enter_the_description_whlie_creating_cnp_project_in_rate_management_in_configuration_analyst()
			throws Exception {

		ensSmoke.clickedOnEditIconOnPricingAnalystApprover_CNP_RMC();
	}

	@Then("user should enter the prioriy as {int} whlie creating CNP Project in Rate Management in Configuration Analyst")
	public void user_should_enter_the_prioriy_as_whlie_creating_cnp_project_in_rate_management_in_configuration_analyst(
			Integer priority) {
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.priority_CNP_RMC), "" + priority + "");
		System.out.println("Entered Priority as " + priority
				+ "  in Priority text box of Rate Management inside Configuration Analyst in rat Management ");
		System.out.println("---------------------------------------------------");

	}

	@Then("user should expand the aggregate section and add the Network code as {string} whlie creating CNP Project in Rate Management  in Configuration Analyst")
	public void user_should_expand_the_aggregate_section_and_add_the_network_code_as_whlie_creating_cnp_project_in_rate_management_in_configuration_analyst(
			String networkCode) {
		ensSmoke.clickOnexpandAggregateBtn_CNP_RMC();
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.networkCodeTextBox), "" + networkCode + "");
		System.out.println("Entered Network Code as " + networkCode
				+ "  in Network Code text box of Configuration Analyst in Rate Management ");
		System.out.println("---------------------------------------------------");

	}
	
	@Then("user should click on Add Network code after entring valid network code whlie creating CNP Project in Rate Management  in Configuration Analyst")
	public void user_should_click_on_Add_netwrok_after_entering_valid_network_code_whike_creating_cnp_project_in_Rate_management_in_config_analyst() {
		ensSmoke.clickOnAddNetworkCodeBtn_CNP_RMC();
	}
	
   	@Then("user should click on send to configuration QA whlie creating CNP Project in Rate Management in Configuration Analyst")
   	public void user_should_click_on_send_to_configuration_QA_while_crating_CNP_Project_In_Rate_Management_In_Confih_Analyst() {
   		ensSmoke.clickOnsendToConfigurationAnalyst_CNP_RMC();
   	}
   	@When("user clicks on configuration QA button whlie creating CNP Project in Rate Management in Configuration Analyst")
   	public void user_clicks_on_config_qa_button_while_creating_CNP_project_in_Rate_management_in_config_analyst()throws Exception {
   		ensSmoke.clickOnConfigurationQA_Btn_CNP_RMC();
   	}
   	@Then("user should enter the decripton while creating CNP Project in Rate Management in Configuration QA and click on the pencil icon")
   	public void  user_should_enter_the_decripton_while_creating_CNP_Project_in_Rate_Management_in_Configuration_QA_and_click_on_the_pencil_icon()throws Exception {
   		ensSmoke.clickedOnEditIconOnPricingAnalystApprover_CNP_RMC();
   	}
   	@Then("user should click on send to configuration analyst in config QA whlie creating CNP Project in Rate Management")
   	public void user_should_click_on_send_to_config_analyst_in_confg_QA_while_creating_CNP_Project_in_Rate_Management() {
   		ensSmoke.clickOnsendToConfigAnalyst_CNP_RMC();
   	}
   	@Then("user should click on withdraw button whlie creating CNP Project in Rate Management")
   	public void user_should_click_on_withdraw_button_while_creating_CNP_Project_in_Rate_Management() {
   		ensSmoke.clickOnWithDrawConfigurationAnalyst_CNP_RMC();
   	}
   	
   	@Then("user should enter withdrwal comment as {string} whlie creating CNP Project in Rate Management")
   	public void user_should_enter_withdrawal_comment_while_creating_CNP_Project_in_Rate_Management(String commentBox) {
   		
		elementutil.Input(ensSmoke.driver.findElement(ensSmoke.withdraw_cmnt_Box_RMC), "" + commentBox + "");
		System.out.println("Entered comment " + commentBox
				+ "  in comment text box of Configuration Analyst in Rate Management ");
		System.out.println("---------------------------------------------------");

   	}
   	@Then("user should click on ok after entering the withdrawal comment whlie creating CNP Project in Rate Management")
   	public void user_should_click_on_ok_after_entering_the_withdrawal_comment_while_creating_CNP_project_in_rate_management() {
   		ensSmoke.clickOnOkBtnOfWithDrawConfigurationAnalyst_RMC();
   	}
	}
