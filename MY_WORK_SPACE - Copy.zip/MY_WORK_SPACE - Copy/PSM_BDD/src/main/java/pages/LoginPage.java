/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */

package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import factory.DriverFactory;
import utilities.ConfigReader;
import utilities.ElementUtil;
import utilities.PasswordEncryption;

public class LoginPage {
	public static String hTitle;
	public static String hTitle1;
	public static String LoggedInUser;
	private WebDriver driver;
	public ElementUtil elementutil = new ElementUtil();
	public PasswordEncryption pwencrypt = new PasswordEncryption(driver);
	static Properties prop;
	private static ConfigReader configReader;
	// LoginPage login = new LoginPage(driver);
	// 1. By Locators
	private By userid = By.id("username");
	private By password = By.id("password");
	private By login_btn = By.id("log_in");
	private By home_Page_Title = By.xpath("//*[@id='collapsiblepanel-header-PricingStrategyCollapse']");
	private By home_Page_Title_of_ENS = By.xpath("//*[@id='div_1_1']/h3");

	// 2.Constructor of the page class
	public void UserEntersENSUrl() {
		DriverFactory.getDriver().get(prop.getProperty("ENSUrl"));
	}

	public void UserEntersPSMUrl() {
		DriverFactory.getDriver().get(prop.getProperty("url"));
	}

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		configReader = new ConfigReader();
		prop = configReader.init_prop();
		// elementutil.implicitWait();
	}

	// 3.Page Actions
	public String getTitle() {
		return driver.getTitle();
	}

	public void enterUserId() {

		// driver.findElement(userid).sendKeys("dmahapat");
		// LoggedInUser=prop.getProperty("support_admin_username");
		// elementutil.Input(driver.findElement(userid), LoggedInUser);
		elementutil.Input(driver.findElement(userid), prop.getProperty("personal_admin_username"));

		// elementutil.Input(driver.findElement(userid), LoggedInUser);
		/*
		 * if(LoggedInasSupportAdminUser==prop.getProperty("support_admin_username"
		 * )) { elementutil.Input(driver.findElement(userid),
		 * LoggedInasSupportAdminUser); }
		 */

	}

	public void enterUserIdForENSA_SUPPORT_USER() {

		elementutil.Input(driver.findElement(userid), prop.getProperty("support_admin_username"));

	}

	public void enterPasswordForENSA_SUPPORT_USER() throws Exception {
		elementutil.Input(driver.findElement(password), pwencrypt.decrypt(prop.getProperty("password_others")));

	}

	public void enterPassword() throws Exception {
		// elementutil.Input(driver.findElement(password),
		// prop.getProperty("password_personal"));
		// elementutil.Input(driver.findElement(password),pwencrypt.decrypt(prop.getProperty("password_personal")));
		elementutil.Input(driver.findElement(password), pwencrypt.decrypt(prop.getProperty("password_personal")));
		// driver.findElement(password).sendKeys("Password-2");
	}

	public void clickSignin() throws Exception {

		// driver.findElement(login_btn).click();
		elementutil.Click(driver.findElement(login_btn));
	}

	public String verifyHomePageTitle() throws Exception {
		// Thread.sleep(10000);
		driver.switchTo().frame(0);
		hTitle = driver.findElement(home_Page_Title).getText();
		return hTitle;
	}

	public String verifyHomePageTitleofENS() throws Exception {
		// Thread.sleep(10000);
		driver.switchTo().frame(0);
		hTitle1 = driver.findElement(home_Page_Title_of_ENS).getText();
		// driver.switchTo().parentFrame();
		return hTitle1;
	}

	public HomePage doHomePageLogin(String un, String pw) {
		System.out.println("Passing username" + un + " and password " + pw);
		// driver.findElement(userid).sendKeys(un);
		elementutil.Input(driver.findElement(userid), un);
		// driver.findElement(password).sendKeys(pw);
		elementutil.Input(driver.findElement(password), pw);
		// driver.findElement(login_btn).click();
		elementutil.Click(driver.findElement(login_btn));
		return new HomePage(driver);

	}

}
