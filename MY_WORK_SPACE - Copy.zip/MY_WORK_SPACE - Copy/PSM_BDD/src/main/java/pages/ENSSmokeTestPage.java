/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */

package pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.ConfigReader;
import utilities.ElementUtil;
import utilities.PasswordEncryption;

public class ENSSmokeTestPage {
	public static String hTitle;
	public String title;
	public static String ContractManageMentTitle;
	public WebDriver driver;
	public ElementUtil elementutil = new ElementUtil();
	static WebDriverWait wait;
	// public PasswordEncryption pwencrypt= new PasswordEncryption(driver);
	static Properties prop;
	private static ConfigReader configReader;
	static Robot robot1;
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public ENSSmokeTestPage(WebDriver driver) {
		this.driver = driver;

	}

	// Generic Locators--------------------------------------
	private By home_Page_Title = By.xpath("//*[@id='collapsiblepanel-header-PricingStrategyCollapse']");
	private By affiliationSection = By.id("collapsiblepanel-header-affiliationSection");
	private By contractSection = By.id("collapsiblepanel-header-contractSection");
	private By rateSection = By.id("collapsiblepanel-header-rateManagement");
	private By e2eRefreshSection = By.id("collapsiblepanel-header-Dashboard_Section1");
	private By dashBoardSection = By.id("collapsiblepanel-header-Dashboard_Section");
	private By adminSection = By.id("collapsiblepanel-header-adminSection");

	private By HomeFieldsofENS = By.xpath("//*[@class='panel-heading']");

	private By QueueFields = By.xpath("//*[@class='text-left']//span");
	private By MaintandDashBoardFields = By.xpath("//*[@class='text-left']");

	// Affiliation Management Locators-----------------------------------
	private By AffiliationManagementLinkBtn = By.id("collapsiblepanel-header-affiliationSection");
	private By AffiliationManagementLink = By.id("pnlHdr-lbl-88");
	private By QueuesOfAffiliationbtn = By.id("collapsiblepanel-header-affiliationQueuesSection");
	private By MaintenanceOfAffiliationbtn = By.id("collapsiblepanel-header-affiliationMaintenanceSection");
	private By AffiliationQueue = By
			.xpath("//*[@class='ContentBox layoutSec valignTop vChild']//div[contains(@class,'SPARKCPanel panel collapsed')]//div[contains(@id,'collapsiblepanel-header-affiliationQueuesSection')]");
	private By AffiliationManintenance = By
			.xpath("//*[@class='ContentBox layoutSec valignTop vChild']//div[contains(@class,'SPARKCPanel panel collapsed')]//div[contains(@id,'collapsiblepanel-header-affiliationMaintenanceSection')]");
	private By ItemsUnderQueues = By.xpath("//*[@id='cpnlData-id-11']/div/div/div");
	private By ItemsUnderMaintenance = By.xpath("//*[@id='cpnlData-id-26']/div/div/div");

	private By submitAffiliationBtnLink = By.xpath("(//*[@class='input SPARKLink'])[1]//p/a");
	private By manualEntryBtnInSubmitAffiliation = By.xpath("//*[@id='manualEntryTab']/a");
	private By addRequestitemBtn = By.xpath("(//*[@id='requestItem']/button)[1]");
	private By requestTypeIdSelectionBox = By.id("requestType");
	public By ncpdpNumberInputBox = By.id("ncpdpNumber");
	public By ncpdpChainCodeInputBox = By.id("chainCodeNumber");
	public By paymentCenterNoInputBox = By.id("paymentCenterNumber");
	private By addEntryBtn = By.xpath("(//*[@class='buttonbar no-margin-bottom']/button)[2]");
	private By submitRequestButton = By.xpath("(//*[@class='btn btn-primary btn-sm'])[1]");
	private By okBtnOnAlertOfSubmitingRqst = By.id("okButton");
	private By closeAlertBtn = By.id("closeButton");
	private By PNAReviewBtn = By
			.xpath("(//*[@class='Task_Link link_item CoachView CoachView_show layoutCell'])[2]//a/span");
	private By ncpdpTextBox = By
			.xpath("(//*[@class='jqx-widget jqx-input jqx-rc-all jqx-input-widget jqx-widget-content'])[6]");
	private By editIconforAddRequestInPnaReview = By.xpath("(//*[div[div[contains(text(),'240')]]]/div)[1]/img");
	private By editIconForTermRequestInPnaReview = By.xpath("(//*[div[div[contains(text(),'246')]]]/div)[1]/img");
	private By MyTaskBtnInAffiliation = By
			.xpath("(//*[@class='Task_Link link_item CoachView CoachView_show layoutCell'])[1]//a/span");

	private By sendToConfigurationBtnInsidePNAReview = By
			.xpath("(//*[@class='buttonbar no-margin-bottom']//button)[7]");
	public By OkBtnOfAlertOfAcceptanceinsidePNAReview = By.id("okConfirmationModal");
	public By clickOutsideOfAffiliationAdd_Aff_Add = By.id("pastAffiliationSection");
	private By OnHoldLinkOfAffiliation = By.xpath("//*[@data-viewid='onHoldLink']");

	private By ncpdpSearchTextBoxOnOnHold = By
			.xpath("/html/body/div[1]/div[7]/div/div[2]/div/div[2]/div/div[2]/div/div[4]/div[1]/div/div/div[4]/div[1]/div[2]/div/div[5]/div/input");
	private By checkBoxOfOnHoldForPharmAdd = By.xpath("((//*[div[div[contains(text(),'240')]]]/div)[1])");
	private By checkBoxOfOnHoldForPharmTerm = By.xpath("((//*[div[div[contains(text(),'246')]]]/div)[1])");
	private By GroupandMoveToConfigQCBtn = By.id("button-button-submitForCodingonHoldGrid");
	private By commentTextBoxInOnHold = By
			.id("textarea-textarea-Group_and_move_to_confirmation_QC_view1:ProjectDescriptionText");
	private By okBtnOnOnHoldProject = By.id("button-button-Group_and_move_to_confirmation_QC_view1:Button2");
	private By configurationBtnInsideAffiliation = By.xpath("//*[@data-viewid='configurationLink']");
	private By configurationQCBtnInsideAffiliation = By.xpath("//*[@data-viewid='configurationQCLink']");

	private By projectDescriptionSearchBox = By
			.xpath("(//span[text()='Project Description']/ancestor::div[contains(@id, 'columntablejqxWidget')]/following-sibling::div[contains(@id, 'filterrow.jqxWidget')]//div[4]//input)[1]");

	private By editIconInsideConfgQC = By
			.xpath("(//*[div[div[contains(text(),'Automation Testing of Sending the project from On Hold')]]]/div)[1]/img");

	private By selectionBoxInsideConfgQC_For_Pharm_Add_AFMC = By
			.xpath("(//*[div[div[contains(text(),'PHARM_ADD')]]])/div[1]/div");
	private By selectionBoxInsideConfgQC_Click_For_Pharm_Add_AFMC = By
			.xpath("(//*[div[div[contains(text(),'PHARM_ADD')]]])/div[1]");
	private By selectionBoxInsideConfgQC_For_Pharm_Term_AFMC = By
			.xpath("(//*[div[div[contains(text(),'246')]]])/div[1]/div");
	private By selectionBoxInsideConfgQC_Click_For_Pharm_Term_AFMC = By
			.xpath("(//*[div[div[contains(text(),'246')]]])/div[1]");

	private By withdrawProjectInsideConfgQc = By.id("withdrawCri");
	private By withDrawReasonSelectionDropdown = By.id("reasonInfo");
	private By commentBoxforwithDrawalinConfgQC = By.id("commentInfo");
	private By okBtnInsideConfgQCforWithdrawalOfProject = By.id("yes");
	private By termReasonDropDown = By.id("termReason");
	private By NPDRetailServiceTypeInSubmitForm = By.xpath("(//*[@class='termRequestSection'])[12]");

	// Contract Management
	// Locators//----------------------------------------------------

	private By ContractManagementBtn = By.xpath("//*[@id='collapsiblepanel-header-contractSection']");
	private By iframeXpath = By.xpath("//div[contains(@id, 'coach_')]/iframe");
	private By QueuesOfContractManagement = By.xpath("//*[@id='collapsiblepanel-header-clientQueuesSection']");
	private By MaintenanceOfContractManagement = By
			.xpath("//*[@id='collapsiblepanel-header-clientMaintenanceSection']");
	private By MaintenanceOfContractManagementBtn = By.id("collapsiblepanel-header-clientMaintenanceSection");// Edited
	private By QueuesOfContractManagementBtn = By
			.xpath("//*[@class='ContentBox layoutSec valignTop vChild']//div[contains(@class,'SPARKCPanel panel collapsed')]//div[contains(@id,'collapsiblepanel-header-clientQueuesSection')]");

	private By MyTaskOfContractManagamentBtn = By.xpath("//*[@id='cpnlData-id-37']/div/div/div[1]/div/div");
	private By HeaderOfContractManagement = By.xpath("/html/body/div[1]/div[7]/div/div[2]/div/div[1]/span");
	private By ItemsUnderQueuesOfContractManagement = By.xpath("//*[@id='cpnlData-id-37']/div/div/div");
	private By ItemsUnderMaintenanceOfContractManagement = By
			.xpath("/html/body/div[1]/div[7]/div/div[1]/div/div[2]/div/div[2]/div/div/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/p/a");
	private By manageClientContractBtn = By.id("link-link-Client_Contract_Mngt2");
	private By CreateProjectBtnOfContractManagement = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-search-form/div/button");
	private By selectHqListDropdown = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-search-form/form/div[1]/select");
	private By inputHqListBoxOfContractManagement = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-search-form/form/div[2]/div/input");
	private By searchBtnOFContractManagement = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-search-form/form/button[1]");

	private By eyeBtntoViewHqListOfContractManagement = By
			.xpath("//*[@class='jqx-grid-content jqx-widget-content']/div[1]/div[1]/div[1]/div/i");

	private By eyebtnleftClick = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-contract-details-view/div[1]/div[1]");
	private By createProjectBtninsideContractMnagement = By
			.xpath("/html/body/app-root/div/app-search/div/div[2]/app-contract-details-view/div[2]/button[2]");
	private By contractManagementProjectRadioBtn = By.xpath("//*[@id='clientContractProject']");
	private By continueBtnOfContractManagement1 = By.xpath("//*[@id='createProjectModal']/div/div/div[3]/button[2]");
	private By AddNewServiceTypeBtnInsideContractManagementCreation = By
			.xpath("/html/body/app-root/div/app-client-contract-management-project/app-project-base/div[1]/div[2]/div/div[2]/app-client-contract-management/div/div[2]/app-client-contract-service-type/div/div[1]/div/span");
	private By withdrawBtnOfMaintProjCreation = By
			.xpath("/html/body/app-root/div/app-client-contract-management-project/app-project-base/div[1]/div[3]/div[2]/button[1]");
	private By enterCommentsBoxInContractMngmntMaintproj = By.id("withdrawComments");

	private By okBtnOfwithDrawProject_CMMC = By
			.xpath("//div[contains(@id, 'withdrawModal')]//button[contains(text(),'Ok')]");
	private By addButtonToAddServiceType = By
			.xpath("/html/body/app-root/div/app-client-contract-management-project/app-project-base/div[1]/div[2]/div/div[2]/app-client-contract-management/div/div[2]/app-client-contract-service-type/div/div[2]/app-service-type-grid/jqxgrid/div/div/div/div[4]/div[2]/div/div[1]/div[2]//i");

	private By SelectionForServiceType = By.xpath("(//*[contains(text(),'RETAIL')])[3]");
	private By choice90SelectionForServiceType = By
			.xpath("//div[contains(@id,'listBoxContentinnerListBoxdropdownlisteditor')]//*[contains(text(),'CHOICE 90')]");
	private By addButtonToAddServiceTypeInClintRate = By
			.xpath("/html/body/app-root/div/app-client-contract-management-project/app-project-base/div[1]/div[2]/div/div[2]/app-client-contract-management/div/div[2]/app-aggregated-client-rate/div/div[2]/app-legacy-aggr-client-rate-grid/jqxgrid/div/div/div/div[4]/div[2]/div/div[1]/div[2]/div/i");
	private By choice90SelectionforServiceTypeInClientRate = By.xpath("(//*[contains(text(),'RETAIL')])[8]");
	private By startDateofClientRate = By.xpath("(//*[contains(text(),'09/30/2020')])[5]");
	private By inputStratDateOfClientrate = By.xpath("//div[@class='jqx-max-size jqx-position-relative']/input");
	private By endDateofClientRate = By.xpath("(//*[contains(text(),'11/07/2020')])[2]");

	private By endDateOfClientRateInput1 = By.xpath("(//*[@class='jqx-grid-cell jqx-item grid-input-changed'])[13]");
	private By sendToContractQAInContractManagement = By.xpath("((//div[@class='float-right'])[2]/button)[3]");
	private By saveButtonInsideContractQAProject = By.xpath("((//div[@class='float-right'])[2]/button)[2]");

	private By contractQABtnonContractMngMnt = By.xpath("//*[@id='cpnlData-id-37']/div/div/div[3]/div/div");
	private By editIconInsideContractQA = By.xpath("//div[div[div[text()='ENSTEST']]]/div/img");
	private By sendBackToContractAnalystBtn = By.xpath("(//*[@class='float-left']/button)[2]");
	private By contractAnalystBtn = By.xpath("//*[@id='cpnlData-id-37']/div/div/div[2]/div/div");
	private By editIconInsideContractAnalyst = By.xpath("(//*[div[div[contains(text(),'ENSTEST')]]]/div)[1]/img");

	// Rate Management Locators//--------------------------Pharmacy List Related
	private By RateManagementBtn = By.id("collapsiblepanel-header-rateManagement");
	private By QueuesOfRateManagementBtn = By.id("collapsiblepanel-header-rateQueuesSection");
	private By MaintenanceOfRateManagementBtn = By.id("collapsiblepanel-header-rateMaintenanceSection");
	private By ItemsUnderQueuesOfRateManagement = By.xpath("//*[@id='cpnlData-id-47']/div/div/div");
	private By ItemsUnderMaintenanceOfRateManagement = By.xpath("//*[@id='cpnlData-id-58']/div/div/div");
	private By managePharmacyListBtn = By.id("link-link-Manage_Pharmacy_List_Link");
	public By pharmacyNameListTextBox = By.id("phaListName");
	public By descriptionBoxOfPharmacyListCreation = By.id("projectDescription");
	private By creteBtn_PLC_RMC = By.xpath("//*[@id='createPhaListSection']//button");
	private By createProjectBtnInRteMngmnt = By.id("createProject");
	public By HqListCodetextBox_RMC = By.id("hqHDRCode");
	public By NABPNo_RMC = By.id("textboxeditoraddPharmacyGridncpdp");
	public By NABP_NO_Click = By.xpath("(//*[@role='gridcell'])[2]");
	private By addButtonOn_RMC = By.xpath("(//*[@id='row0addPharmacyGrid']/div/div)[1]/i");
	private By sendToConfigQA_RMC = By.xpath("//*[@class='btn btn-primary send-next-queue-btn']");
	private By configruationQaBtn_RMC = By.xpath("//*[@data-viewid='configurationQALink']");
	private By projectDescription_RMC_InCongQC = By
			.xpath("(//*[@class='jqx-grid jqx-reset jqx-rc-all jqx-widget jqx-widget-content'])[7]//div[5]/div/input");
	private By editIconOn_Cong_QA_RMC = By
			.xpath("(//*[div[div[contains(text(),'Test Creation Of Pharmacy List In Rate Management')]]]/div)[1]/img");
	private By sendBackToConfigAnalystBtn_RMC = By.xpath("//*[@class='btn btn-default send-back-role-btn']");
	private By configurationAnalystBtn_RMC = By.xpath("//*[@data-viewid='configurationAnalystLink']");
	private By withdrawBtn_ConfigAnalyst_RMC = By.xpath("//*[@class='btn btn-default withdraw-btn']");
	public By withdraw_cmnt_Box_RMC = By.id("reasonMessage");
	private By okBtn_RMC = By.id("yesMsg");

	// Rate management Locators//---------------------------BB creation
	// locators//-------------------

	private By manageBuildingBlockBtn_RMC = By.id("link-link-Manage_Bldg_Block_Link");
	public By clickOnBBName_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[2]");
	public By enterOnBBName_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[2]/input");
	private By ServiceType_Drop_Down_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[4]");
	private By ServiceType_Drop_Down_RMC1 = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[5]");
	private By ABB_Drop_Down_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[6]");
	private By BuildingBlockType_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[8]");
	private By LOB_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[10]");
	private By pharmacy_Type_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[16]");
	public By pharmacy_identifierClick_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[18]");
	public By pharmacy_identifier_Click_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[18]");
	public By pharmacy_identifier_input_RMC = By.xpath("(//*[@id='contenttableaddBBGrid']/div/div)[18]/input");
	public By outsideClick_BB_RMC = By.xpath("//*[@class='padding-25 clearfix']/div[2]/div/div/div/div[2]");
	public By horizontal_Scrol_Bar = By.id("jqxScrollThumbhorizontalScrollBaraddBBGrid");
	private By Add_BB_Btn_RMC = By.xpath("//*[@class='fa fa-plus']");
	private By saveButton_BB_Creation_RMC = By.xpath("//*[@class='btn btn-tertiary save-progress-btn']");
	private By sendToPricingApproverBtn_BB_RMC = By.xpath("//*[@id='actionButtons']/div/span[2]/button[3]");
	private By pricingAnalystApproverBtn = By.xpath("//*[@data-viewid='pricingAnalystApproverLink']");
	private By projectDescriptionTextBox = By
			.xpath("/html/body/div[1]/div[7]/div/div[2]/div/div[2]/div/div[6]/div/div[3]/div[1]/div/div/div[4]/div[1]/div[2]/div/div[5]/div/input");
	private By editIconOn_Pricing_Analyst_Approver_RMC = By
			.xpath("(//*[div[div[contains(text(),'Automation of Creation of BB')]]]/div)[1]/img");
	private By sendToPricingAnalystBtn_RMC = By.xpath("//*[@id='actionButtons']//span[1]/button[2]");
	private By pricingAnalystButton_RMC = By.xpath("//*[@data-viewid='pricingAnalystLink']");
	private By manageCNPBtn_RMC = By.id("link-link-manageCnp");

	// Rate management Locators//---------------------------CNP creation
	// locators---------------------------
	private By hqListSelectionBox_RMC = By.id("searchByTypeSelector");
	public By projectname_CNP_Creation_RMC = By.id("searchByValue");
	private By searchBtn_CNP_Creation_RMC = By.id("searchBtn");
	private By eyeBtnInCNPCreation_RMC = By
			.xpath("//*[@class='jqx-grid-content jqx-widget-content']/div[1]/div[3]/div[1]/div/div");
	private By CreateProjectBtnInCNPCreation_RMC = By.id("createProjButton");
	private By selectRetail_CNP_RMC = By
			.xpath("//*[@class='jqx-listitem-state-normal jqx-item jqx-rc-all jqx-listitem-state-selected jqx-fill-state-pressed']");
	private By servicTypeSelection_CNP_RMC = By.id("listitem0serviceType");
	public By description_CNP_RMC = By.id("projDesMsg");
	private By continueBtn_CNP_RMC = By.id("continueButtonProj");
	private By BBTypeDropDown_CNP_RMC = By.id("bbTypeR");
	private By BbNameDropDown_CNP_RMC = By.id("dropdownlistContentbbNameR");
	private By addBtn_CNP_RMC = By.xpath("(//*[@class='btn btn-default bb-n-btn addButton pull-right'])[1]");
	public By brandDicountTextBox_CNP_RMC = By.id("textboxeditorphaGridR0brandDiscount");
	private By brandDiscountClick_CNP_RMC = By
			.xpath("(//*[@class='jqx-grid-cell jqx-item jqx-grid-cell-wrap input-required'])[1]");
	private By PriceCodeClick_CNP_RMC = By
			.xpath("//*[@class='jqx-grid-cell jqx-item jqx-grid-cell-wrap input-required jqx-grid-cell-selected jqx-fill-state-pressed']");
	public By brandFellFeeTextBox_CNP_RMC = By.id("textboxeditorphaGridR0brandFillFee");
	public By genericDiscountTextBox_CNP_RMC = By.id("textboxeditorphaGridR0genericDiscount");
	public By genericFillFeeTextBox_CNP_RMC = By.id("textboxeditorphaGridR0genericFillFee");
	public By priceCodetextBox_CNP_RMC = By.id("textboxeditorphaGridR0priceCode");
	private By saveProgressBtn_CNP_RMC = By.id("saveProgress");

	public By brandDiscountTextBox_Client_Rate_CNP_RMC = By.id("textboxeditorclientRateGridRbrandDiscount");
	public By brandFillFeeTextBox_Client_Rate_CNP_RMC = By.id("textboxeditorclientRateGridRbrandFillFee");
	public By genericDiscountTextBox_Client_Rate_CNP_RMC = By.id("textboxeditorclientRateGridRgenericDiscount");
	public By genericFillFeeTextBox_Client_Rate_CNP_RMC = By.id("textboxeditorclientRateGridRgenericFillFee");
	public By priceCodeTestBox_Client_Rate_CNP_RMC = By.id("textboxeditorclientRateGridRpriceCode");

	private By sendToPricingApproverBtn_CNP_RMC = By.id("sendToPAApprover");
	private By PricingApproverAnalystBtn_CNP_RMC = By.xpath("//*[@data-viewid='pricingAnalystApproverLink']");
	private By editIconInPricingAnalystPrrover_CNP_RMC = By
			.xpath("(//*[div[div[contains(text(),'Testing Creating CNP Maintenance Project')]]]/div)[1]/img");
	private By sendToConfigAnalystBtn_CNP_RMC = By.id("sendToConfigAnalyst");
	private By configurationAnalystBtn_CNP_RMC = By.xpath("//*[@data-viewid='configurationAnalystLink']");
	public By priority_CNP_RMC = By.id("priorityR0");
	public By expandAggregateBtn_CNP_RMC = By.xpath("(//*[@id='bbTpIdR0']/i)[1]");
	public By networkCodeTextBox = By.id("searchR0");
	private By addNetwrokCode = By.id("addR0");
	private By sendToConfigQA_CNP_RMC = By.id("sendToConfigQA");
	private By configQA_RMC = By.xpath("//*[@data-viewid='configurationQALink']");
	private By sendBackToConfigurationAnalyst_CNP_RMC = By.id("sendBackToConfigAnalystBtn");
	private By withDrawBtn_CNP_RMC = By.id("withdraw");

	public String verifyHomePageTitle() {
		// Thread.sleep(10000);
		driver.switchTo().frame(0);
		hTitle = driver.findElement(home_Page_Title).getText();
		return hTitle;
	}

	public List<String> getHomePageItemListofENS() {
		String affiliationText = driver.findElement(affiliationSection).getText();
		String contractSectionText = driver.findElement(contractSection).getText();
		String rateSectionText = driver.findElement(rateSection).getText();
		String e2eRefreshSectionText = driver.findElement(e2eRefreshSection).getText();
		String dashBoardSectionText = driver.findElement(dashBoardSection).getText();
		String adminSectionText = driver.findElement(adminSection).getText();
		List<String> homePageItemListOfEns = new ArrayList<String>();
		homePageItemListOfEns.add(affiliationText);
		homePageItemListOfEns.add(contractSectionText);
		homePageItemListOfEns.add(rateSectionText);
		homePageItemListOfEns.add(e2eRefreshSectionText);
		homePageItemListOfEns.add(dashBoardSectionText);
		homePageItemListOfEns.add(adminSectionText);
		System.out.println(homePageItemListOfEns);
		return homePageItemListOfEns;

	}

	public String getHeaderOfAffliationManagement() throws Exception {
		elementutil.explicitWait(AffiliationManagementLink, driver);

		String affiliationText = driver.findElement(AffiliationManagementLink).getText();
		System.out.println("Actual affiliationText +++" + affiliationText);
		return affiliationText;
	}

	public void clickOnAffiliationLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++  Affiliation Managemnt");
		elementutil.explicitWait(AffiliationManagementLinkBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(AffiliationManagementLinkBtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Affiliation");
	}

	public List<String> getFieldsunderAffiliationManagement() {
		List<String> AffiliationFieldList = new ArrayList<String>();
		elementutil.explicitWait(AffiliationQueue, driver);
		elementutil.explicitWait(AffiliationManintenance, driver);
		String QueueOfAffiliatioan = driver.findElement(AffiliationQueue).getText();
		String MaintenanceOfAffiliation = driver.findElement(AffiliationManintenance).getText();
		AffiliationFieldList.add(QueueOfAffiliatioan);
		AffiliationFieldList.add(MaintenanceOfAffiliation);
		System.out.println("AffiliationFieldList  " + AffiliationFieldList);
		return AffiliationFieldList;

	}

	public void clickOnQueuesofAffiliationLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(QueuesOfAffiliationbtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(QueuesOfAffiliationbtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Queues of Affiliation");
	}

	public void clickOnMaintenanceOfAffiliationLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(MaintenanceOfAffiliationbtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(MaintenanceOfAffiliationbtn));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Maintenance of Affiliation");
	}

	public List<String> getQueuesItemListUnderAffiliation() {
		List<String> ItemsUnderQueueList = new ArrayList<String>();
		elementutil.explicitWait(ItemsUnderQueues, driver);
		// driver.switchTo().frame(0);
		List<WebElement> itemsUnderQueue = driver.findElements(ItemsUnderQueues);

		for (WebElement e : itemsUnderQueue) {
			String text = e.getText();
			// System.out.println("Items of Home Page of PSM" + text);
			ItemsUnderQueueList.add(text);
			System.out.println("Items under Queues of Affiliation Management :" + text);
		}
		return ItemsUnderQueueList;
	}

	public List<String> getMaintenanceItemListUnderAffiliation() {
		List<String> ItemsUnderMaintenanceList = new ArrayList<String>();
		// driver.switchTo().frame(0);
		elementutil.explicitWait(ItemsUnderMaintenance, driver);
		List<WebElement> itemsUnderMaintenance = driver.findElements(ItemsUnderMaintenance);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsUnderMaintenance) {
			String text = e.getText();
			// System.out.println("Items of Home Page of PSM" + text);
			ItemsUnderMaintenanceList.add(text);
			System.out.println("Items under Maintenance of Affiliation Management :" + text);
		}
		return ItemsUnderMaintenanceList;
	}

	public void clickOnSubmitAffiliationBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(submitAffiliationBtnLink, driver);
		elementutil.javaScrptClick(driver, driver.findElement(submitAffiliationBtnLink));
		System.out.println("Clicked on ok submit Affiliation button in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void click_On_Manual_Entry_Btn_of_Submit_Form_AFMC() {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(manualEntryBtnInSubmitAffiliation)).click();
		System.out
				.println("Clicked on Manual Entry Button of Submit Affiliation to add Pharmacy in Affiliation Management Project");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnaddRequestBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(addRequestitemBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(addRequestitemBtn));
		System.out.println("Clicked on ok add Request button in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void selectPharm_add_from_request_typeDropDown() {
		elementutil.explicitWait(requestTypeIdSelectionBox, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(requestTypeIdSelectionBox), "PHARM_ADD");
		System.out.println("Selected Dropdown pharm add from request type in affiliation--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void enter_Ncpdp_Number_Into_Request_Type_Box_pharmadd_in_AFMC() {
		elementutil.explicitWait(ncpdpNumberInputBox, driver);

	}

	public void enter_NCPDP_CHAIN_CODE_Number_Into_Request_Type_Box_pharmadd_in_AFMC() {
		elementutil.explicitWait(ncpdpChainCodeInputBox, driver);

	}

	public void enter_Payment_Center_Number_Into_Request_Type_Box_pharmadd_in_AFMC() {
		elementutil.explicitWait(paymentCenterNoInputBox, driver);

	}

	public void clickOnaddEntrytBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(addEntryBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(addEntryBtn));
		System.out.println("Clicked on Add Entryy Button in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnSubmitRqstBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(submitRequestButton, driver);
		elementutil.javaScrptClick(driver, driver.findElement(submitRequestButton));
		System.out.println("Clicked on Submit Request Button in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnOkBtnAfterSubmitRqstBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(okBtnOnAlertOfSubmitingRqst, driver);
		elementutil.javaScrptClick(driver, driver.findElement(okBtnOnAlertOfSubmitingRqst));
		System.out.println("Clicked on Ok Button on submitting a request in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOncloseAlertBtnAfterSubmitRqstBtnOfAffiliationManagement_AFMC() {
		elementutil.explicitWaitUntilElementIsClickable(closeAlertBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(closeAlertBtn));
		System.out.println("Clicked on Close Button after submitting a request in Affiliation Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnPNAReviewBtnOfAffiliationManagement_AFMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on PNA Review Button of Affiliation Management");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(PNAReviewBtn)).click();

		System.out.println("Clicked on PNA Review button on Affiliation Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void entercreatedprojectandClickOnEditOFAffiliationManagement() throws Exception {
		Thread.sleep(7000);
		elementutil.explicitWait(ncpdpTextBox, driver);
		elementutil.Input(driver.findElement(ncpdpTextBox), "240");
		System.out.println("Entered Text in Serach box of PNA Review Of Affiliation mnagement ");
		elementutil.explicitWait(editIconforAddRequestInPnaReview, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconforAddRequestInPnaReview)).click();
		System.out.println("Clicked on Edit Icon of Created Project inside PNA Review Of Affiliation Management");
		Thread.sleep(4000);

		System.out.println("---------------------------------------------------");
	}

	public void click_On_send_to_configuration_btn_of_Created_Project_AFMC() throws Exception {
		elementutil.switchToNewTab(driver);
		Thread.sleep(5000);
		driver.manage().window().maximize();
		Thread.sleep(4000);
		driver.navigate().refresh();
		Thread.sleep(4000);
		driver.navigate().refresh();
		System.out.println("Page is refreshed Twice");
		Thread.sleep(8000);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(sendToConfigurationBtnInsidePNAReview));
		System.out.println("Clicked on send to Configuration Button");
		wait.until(ExpectedConditions.elementToBeClickable(OkBtnOfAlertOfAcceptanceinsidePNAReview)).click();
		System.out.println("Clicked on ok Button Alert ");
		System.out.println("---------------------------------------------------");
		Thread.sleep(3000);
	}

	public void clickOnHoldLink() throws Exception {
		// Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on On Hold Button of Affiliation Management");
		elementutil.explicitWait(OnHoldLinkOfAffiliation, driver);
		// Thread.sleep(4000);
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(OnHoldLinkOfAffiliation)).click();
		Thread.sleep(3000);

		elementutil.Click(driver.findElement(OnHoldLinkOfAffiliation));

		System.out.println("Clicked On Hold button on Affiliation Management for project creation");
		System.out.println("---------------------------------------------------");
	}

	public void selectTheProjectInOnHold() throws Exception {
		Thread.sleep(6000);
		elementutil.explicitWait(ncpdpSearchTextBoxOnOnHold, driver);
		elementutil.Input(driver.findElement(ncpdpSearchTextBoxOnOnHold), "240");
		System.out.println("Entered Text in Serach box of On Hold of Affiliation mnagement ");
		elementutil.explicitWait(checkBoxOfOnHoldForPharmAdd, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(checkBoxOfOnHoldForPharmAdd)).click();
		System.out.println("Clicked on check Box of Created Project inside On Hold Of Affiliation Management");
		Thread.sleep(4000);
	}

	public void clickOnGroupandMoveToCongQC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(GroupandMoveToConfigQCBtn)).click();
		System.out.println("User clicked on Group and configuration QC Button");
		System.out.println("---------------------------------------------------");
	}

	public void enterTheMessageafterGrpAndConfgQC() {
		elementutil.Input(driver.findElement(commentTextBoxInOnHold),
				"Automation Testing of Sending the project from On Hold");
		System.out.println("User entered the message into the message box after clicking on grpandconfg QC");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnOkBtnInsieOnHold() throws Exception {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(okBtnOnOnHoldProject)).click();
		System.out.println("User clicked on Ok button of Comment Box Inside OnHold");
		System.out.println("---------------------------------------------------");
		Thread.sleep(7000);
	}

	public void clickOnConfigurationOfAffiliation() {

		elementutil.waitForDomLoad(driver);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(configurationBtnInsideAffiliation));
		System.out.println("User clicked on Configuration Twice");
	}

	public void clickOnConfigurationQCBtnOfAffiliation() throws Exception {

		Thread.sleep(5000);
		elementutil.waitForDomLoad(driver);
		elementutil.Click(driver.findElement(configurationQCBtnInsideAffiliation));
		System.out.println("User clicked on Configuration QC inside Affiliation Management");
	}

	public void clicksOnTheProjectinConfigQC_AFMC() {
		elementutil.Input(driver.findElement(projectDescriptionSearchBox),
				"Automation Testing of Sending the project from On Hold");
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconInsideConfgQC)).click();
		System.out.println("User clicked on pencil incon of Configuration QC inside Affiliation Management");
	}

	public void selectTheProjectinConfigQC_In_Pharm_Add_AFMC() throws Exception {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		driver.navigate().refresh();
		System.out.println("Page is refreshed");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(selectionBoxInsideConfgQC_For_Pharm_Add_AFMC));
		System.out.println("Scroll down in Configuration QC");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(selectionBoxInsideConfgQC_Click_For_Pharm_Add_AFMC)).click();
		System.out.println("user selected the created project inside Config QC of Affiliation Management");
	}

	public void clicksOnWithdrawProjectinConfigQC_AFMC() {
		wait = new WebDriverWait(driver, 10);
		elementutil.waitForDomLoad(driver);
		wait.until(ExpectedConditions.elementToBeClickable(withdrawProjectInsideConfgQc)).click();
		System.out.println("user clicks on withdraw project inside Config QC of Affiliation Management");
	}

	public void selectReasonOfWithdrawalfromDropDownInConfigQA_AFMC() {
		elementutil.explicitWait(withDrawReasonSelectionDropdown, driver);
		elementutil.waitForDomLoad(driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(withDrawReasonSelectionDropdown), "DUPLICATE_REQUEST");
		System.out.println("-------------------------------------------------------------------------------------");
		System.out.println("Selected withdraw Dropdown inside Config QA in Affiliation Management--------------------");
	}

	public void enterdIntoWithdrawalCommentBoxOfCreatedProjectinConfigQC_AFMC() {
		elementutil.waitForDomLoad(driver);
		elementutil.Input(driver.findElement(commentBoxforwithDrawalinConfgQC),
				"Withdrawing the pharm add which is created in Automation ");
		System.out
				.println("Entered comment into comment box while withdrawing the project from Config QA in Affiliation Management");
	}

	public void clicksOnOkInWithdrawProjectinConfigQC_AFMC() {
		wait = new WebDriverWait(driver, 10);
		elementutil.waitForDomLoad(driver);
		wait.until(ExpectedConditions.elementToBeClickable(okBtnInsideConfgQCforWithdrawalOfProject)).click();
		System.out.println("user clicks on ok of withdarwal of project box inside Config QC of Affiliation Management");
	}

	public void selectPharm_term_from_request_typeDropDown_AFMC() {
		elementutil.explicitWait(requestTypeIdSelectionBox, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(requestTypeIdSelectionBox), "PHARM_TERM");
		System.out.println("Selected Dropdown pharm term from request type in affiliation--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void selectTheProjectinConfigQC_In_Pharm_Term_AFMC() throws Exception {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(selectionBoxInsideConfgQC_For_Pharm_Term_AFMC));
		System.out.println("Scroll down in Configuration QC while Terming the pharmacy");
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(selectionBoxInsideConfgQC_Click_For_Pharm_Term_AFMC))
				.click();

		System.out
				.println("user selected the created project inside Config QC of Affiliation Management while terming the pharmacy");
	}

	public void select_Term_Reason_DropDown_AFMC() {
		elementutil.explicitWait(termReasonDropDown, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(termReasonDropDown), "TERM_FOR_CAUSE");
		System.out
				.println("Selected Dropdown from term reason for pharm term from request type in affiliation--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void entercreatedprojectToBeTermedandClickOnEditOFAffiliationManagement() throws Exception {
		Thread.sleep(7000);
		elementutil.explicitWait(ncpdpTextBox, driver);
		elementutil.Input(driver.findElement(ncpdpTextBox), "246");
		System.out.println("Entered NCPDP No To Be termed in Serach box of PNA Review Of Affiliation mnagement ");
		elementutil.explicitWait(editIconForTermRequestInPnaReview, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconForTermRequestInPnaReview)).click();
		System.out.println("Clicked on Edit Icon of Created Project inside PNA Review Of Affiliation Management");
		Thread.sleep(4000);

		System.out.println("---------------------------------------------------");
	}

	public void selectThePharmTermProjectInOnHold() throws Exception {
		Thread.sleep(6000);
		elementutil.explicitWait(ncpdpSearchTextBoxOnOnHold, driver);
		elementutil.Input(driver.findElement(ncpdpSearchTextBoxOnOnHold), "246");
		System.out.println("Entered Text in Serach box of On Hold of Affiliation mnagement ");
		elementutil.explicitWait(checkBoxOfOnHoldForPharmTerm, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(checkBoxOfOnHoldForPharmTerm)).click();
		System.out
				.println("Clicked on check Box of Created Project for pharm term inside On Hold Of Affiliation Management");
		Thread.sleep(4000);
	}

	public void click_On_send_to_configuration_btn_of_Created_Project_For_Pharm_Term_AFMC() throws Exception {
		elementutil.switchToNewTab(driver);
		Thread.sleep(5000);
		driver.manage().window().maximize();
		Thread.sleep(4000);

		Thread.sleep(8000);

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(sendToConfigurationBtnInsidePNAReview));
		System.out.println("Clicked on send to Configuration Button");
		System.out.println("---------------------------------------------------");
		Thread.sleep(8000);
	}

	public void clickOnContractManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");

		if (driver.findElement(iframeXpath).isDisplayed()) {
			driver.switchTo().frame(0);
		}
		System.out.println("Expected to work in fluent wait for contract management");
		elementutil.explicitWait(ContractManagementBtn, driver);
		System.out.println("Fluent wait worked");

		elementutil.javaScrptClick(driver, driver.findElement(ContractManagementBtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Contract Management");
	}

	public List<String> getFieldsunderContractManagement() {
		List<String> ContractManagementFieldList = new ArrayList<String>();
		elementutil.explicitWait(QueuesOfContractManagement, driver);
		elementutil.explicitWait(MaintenanceOfContractManagement, driver);
		String QueueOfContractManagement = driver.findElement(QueuesOfContractManagement).getText();
		String MaintenanceOfContractManagementfield = driver.findElement(MaintenanceOfContractManagement).getText();
		ContractManagementFieldList.add(QueueOfContractManagement);
		ContractManagementFieldList.add(MaintenanceOfContractManagementfield);
		System.out.println("Contract management Field List  " + ContractManagementFieldList);
		return ContractManagementFieldList;

	}

	public void clickOnQueueOfContractManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(QueuesOfContractManagement, driver);
		elementutil.javaScrptClick(driver, driver.findElement(QueuesOfContractManagement));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Queues of Contract Management");
	}

	public void clickOnMyTaskOfContractManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(MyTaskOfContractManagamentBtn, driver);

		elementutil.javaScrptClick1(driver, driver.findElement(MyTaskOfContractManagamentBtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on My task of Contract Management");
	}

	public String verifyContractManagementPageTitle() throws Exception {

		elementutil.explicitWait(HeaderOfContractManagement, driver);
		ContractManageMentTitle = driver.findElement(HeaderOfContractManagement).getText();
		System.out.println(" Actual ContractManageMentTitle :: " + ContractManageMentTitle);
		return ContractManageMentTitle;
	}

	public List<String> getQueuesItemListUnderContractManagement() {
		List<String> ItemsUnderQueuesOfContractManagemtList = new ArrayList<String>();
		// driver.switchTo().frame(0);
		List<WebElement> itemsUnderQueuesOfContractManagement = driver
				.findElements(ItemsUnderQueuesOfContractManagement);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsUnderQueuesOfContractManagement) {
			String text = e.getText();
			// System.out.println("Items of Home Page of PSM" + text);
			ItemsUnderQueuesOfContractManagemtList.add(text);
			System.out.println("Items under Queues of Contract Management :" + text);
		}
		return ItemsUnderQueuesOfContractManagemtList;
	}

	public void clickOnMaintenanceLinkUnderContractManagement() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		TimeUnit.SECONDS.sleep(3);
		elementutil.explicitWait(MaintenanceOfContractManagement, driver);
		elementutil.javaScrptClick(driver, driver.findElement(MaintenanceOfContractManagement));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Maintenance of Contract Management");
	}

	public List<String> getMaintenanceItemListUnderContractManagement() {
		List<String> ItemsUnderMaintenanceOfContractManagemtList = new ArrayList<String>();
		// driver.switchTo().frame(0);
		elementutil.explicitWait(ItemsUnderMaintenanceOfContractManagement, driver);
		List<WebElement> itemsUnderMaintOfContractManagement = driver
				.findElements(ItemsUnderMaintenanceOfContractManagement);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsUnderMaintOfContractManagement) {
			String text = e.getText();
			// System.out.println("Items of Home Page of PSM" + text);
			ItemsUnderMaintenanceOfContractManagemtList.add(text);
			System.out.println("Items under Maintenance of Contract Management :" + text);
		}
		return ItemsUnderMaintenanceOfContractManagemtList;
	}

	public void clickOnManageClientContractBtnOfContractManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(manageClientContractBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(manageClientContractBtn));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Manage Client Contract of Contract Management");
	}

	public void verifytPageTitleOfClientContractManagement() throws Exception {

		System.out.println("Inside Pop up");

		elementutil.explicitWait(CreateProjectBtnOfContractManagement, driver);
		elementutil.javaScrptClick(driver, driver.findElement(CreateProjectBtnOfContractManagement));
	}

	public void selectHqListCodefromDropDown() throws Exception {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		// Thread.sleep(6000);
		elementutil.explicitWait(selectHqListDropdown, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(selectHqListDropdown), "1: Object");
		System.out.println("Selected Dropdown--------------------");
	}

	public void enterHqCodeIntoinputBoxOFContractManagement() {
		elementutil.explicitWait(inputHqListBoxOfContractManagement, driver);
		elementutil.Input(driver.findElement(inputHqListBoxOfContractManagement), "ENSTEST");
		System.out.println("Entered Text in Serach box of Clint mnagement ");
	}

	public void clickOnSearchBtnOfContractManagementLink() {
		elementutil.explicitWait(searchBtnOFContractManagement, driver);
		elementutil.javaScrptClick(driver, driver.findElement(searchBtnOFContractManagement));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Search button inside Contract Management creation");
	}

	public void clickOneyeBtntoViewHqListOfContractManagement() throws Exception {
		elementutil.explicitWait(eyeBtntoViewHqListOfContractManagement, driver);
		TimeUnit.SECONDS.sleep(4);

		wait = new WebDriverWait(driver, 10);
		wait.until(
				ExpectedConditions.elementToBeClickable(By
						.xpath("//*[@class='jqx-grid-content jqx-widget-content']/div[1]/div[1]/div[1]/div/i")))
				.click();

		TimeUnit.SECONDS.sleep(4);

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on eye button inside Contract Management creation");
	}

	public void clickOCreateProjectOfContractManagement() {
		elementutil.explicitWait(createProjectBtninsideContractMnagement, driver);
		elementutil.javaScrptClick(driver, driver.findElement(createProjectBtninsideContractMnagement));
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Create Project button while creating maintainance project on Contract Management creation");
	}

	public void clickOncontractManagementProjectOfContractManagement() {
		elementutil.explicitWait(contractManagementProjectRadioBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(contractManagementProjectRadioBtn));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on client contract management project on Contract Management creation");
	}

	public void clickOnContinueBtnOfContractManagementforMaintainanceProjectCreation() {
		elementutil.explicitWait(continueBtnOfContractManagement1, driver);
		elementutil.javaScrptClick(driver, driver.findElement(continueBtnOfContractManagement1));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Continue Button for Maintaianance Project Creation on Contract Management");
	}

	public void clickOnAddNewSvcTypeBtnInsideMaintProjCreation_CMMC() {
		elementutil.explicitWait(AddNewServiceTypeBtnInsideContractManagementCreation, driver);
		elementutil.javaScrptClick(driver, driver.findElement(AddNewServiceTypeBtnInsideContractManagementCreation));
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add New Service Type inside Maintaianance Project Creation on Contract Management");
	}

	public void clickOnAddNewAllServiceType() throws Exception {
		elementutil.explicitWait(addButtonToAddServiceType, driver);
		TimeUnit.SECONDS.sleep(4);
		wait = new WebDriverWait(driver, 10);
		wait.until(
				ExpectedConditions.elementToBeClickable(By
						.xpath("/html/body/app-root/div/app-client-contract-management-project/app-project-base/div[1]/div[2]/div/div[2]/app-client-contract-management/div/div[2]/app-client-contract-service-type/div/div[2]/app-service-type-grid/jqxgrid/div/div/div/div[4]/div[2]/div/div[1]/div[2]//i")))
				.click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add Button in Service Type Maintaianance Project Creation on Contract Management");
	}

	public void selectChoice90fromServiceTypeDropDown() throws Exception {
		elementutil.explicitWait(SelectionForServiceType, driver);
		TimeUnit.SECONDS.sleep(4);
		elementutil.scrollDown();
		elementutil.ClickEvent(driver, SelectionForServiceType);
		TimeUnit.SECONDS.sleep(3);
		elementutil.clickUpp();
		TimeUnit.SECONDS.sleep(4);
		System.out.println("Selected Dropdown on Service type Add--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnAddNewAllServiceTypeInClientRateManagement() throws Exception {
		elementutil.explicitWait(addButtonToAddServiceTypeInClintRate, driver);
		TimeUnit.SECONDS.sleep(4);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(addButtonToAddServiceTypeInClintRate)).click();
		TimeUnit.SECONDS.sleep(4);
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add service Type Button in Client Rate managament in Maintaianance Project Creation on Contract Management");
	}

	public void selectChoice90fromServiceTypeDropDownInClientRate() throws Exception {
		elementutil.explicitWait(choice90SelectionforServiceTypeInClientRate, driver);
		TimeUnit.SECONDS.sleep(4);
		elementutil.scrollDown();
		elementutil.ClickEvent(driver, choice90SelectionforServiceTypeInClientRate);
		TimeUnit.SECONDS.sleep(2);
		elementutil.clickUpp();
		TimeUnit.SECONDS.sleep(4);
		System.out.println("Selected Dropdown on Client rate Add--------------------");
		System.out.println("---------------------------------------------------");

	}

	public void enterStartDateInClientRate() throws Exception {
		// ZoneId zid = ZoneId.of("-12:30");
		ZoneId zid = ZoneId.of("America/Los_Angeles");
		// create an LocalDate object using now(zoneId)
		LocalDate startDate = LocalDate.now(zid);
		System.out.println("startDate__ " + startDate);
		/*
		 * LocalTime updatedTime =
		 * time.minusHours(2).minusMinutes(30).minusSeconds(30);
		 * System.out.println(updatedTime);
		 */
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
		String startDate1 = formatter.format(startDate);
		System.out.println("Formatted Date__" + startDate1);
		// Thread.sleep(5000);
		TimeUnit.SECONDS.sleep(5);
		elementutil.ClickEvent(driver, startDateofClientRate);
		// Thread.sleep(5000);
		TimeUnit.SECONDS.sleep(5);
		robot1 = new Robot();
		robot1.keyPress(KeyEvent.VK_DELETE);
		robot1.keyRelease(KeyEvent.VK_DELETE);
		Thread.sleep(4000);
		StringSelection dt = new StringSelection(startDate1);
		Clipboard clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipBoard.setContents(dt, null);
		// Thread.sleep(1000);
		TimeUnit.SECONDS.sleep(2);
		robot1.keyPress(KeyEvent.VK_CONTROL);
		robot1.keyPress(KeyEvent.VK_V);
		// Thread.sleep(1000);
		TimeUnit.SECONDS.sleep(2);
		robot1.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(5000);
		System.out.println("Entered Start Date");
		System.out.println("---------------------------------------------------");
	}

	public void enterEndDateInClientRate() throws Exception {
		ZoneId zid = ZoneId.of("America/Los_Angeles");
		LocalDate startDate = LocalDate.now(zid);
		System.out.println("startDate__ " + startDate);
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM/dd/YYYY");
		String startDate1 = formatter1.format(startDate);
		LocalDate endDate = LocalDate.now().plusDays(666);
		;
		System.out.println("endDate__ " + endDate);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
		String endDate1 = formatter.format(endDate);
		System.out.println("Formatted Date__" + endDate1);
		Thread.sleep(5000);
		elementutil.ClickEvent(driver, endDateofClientRate);
		Thread.sleep(5000);
		robot1 = new Robot();
		robot1.keyPress(KeyEvent.VK_DELETE);
		robot1.keyRelease(KeyEvent.VK_DELETE);
		Thread.sleep(4000);
		StringSelection dt = new StringSelection(endDate1);
		Clipboard clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipBoard.setContents(dt, null);
		Thread.sleep(1000);
		robot1.keyPress(KeyEvent.VK_CONTROL);
		robot1.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		robot1.keyRelease(KeyEvent.VK_CONTROL);
		robot1.keyRelease(KeyEvent.VK_V);
		Thread.sleep(5000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(),'" + startDate1 + "')])[2]")))
				.click();
		// elementutil.ClickEvent(driver,endDateOfClientRateInput1);
		System.out.println("Entered End Date");
		System.out.println("---------------------------------------------------");
	}

	public void clickonSaveButtonContractManagement() throws Exception {
		Thread.sleep(4000);

		wait = new WebDriverWait(driver, 15);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,750)");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='float-right'])[2]/button[2]")))
				.click();
		Thread.sleep(6000);
		System.out.println("Clicked on Save Progress Button on Contract Management maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickonSendToContractQAOfContractManagement() throws Exception {
		elementutil.explicitWait(sendToContractQAInContractManagement, driver);

		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("((//div[@class='float-right'])[2]/button)[3]")))
				.click();
		System.out.println("Clicked on send to conract QA on Contract Management maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnContractQABtnOfContractManagement() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on contract QA");
		elementutil.explicitWait(contractQABtnonContractMngMnt, driver);
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(contractQABtnonContractMngMnt)).click();

		System.out.println("Clicked on conract QA button on Contract Management maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void click_On_Edit_Icon_of_Created_Project_on_contract_QA_CMMC() {
		elementutil.explicitWait(editIconInsideContractQA, driver);
		elementutil.Click(driver.findElement(editIconInsideContractQA));
		System.out
				.println("Clicked on Edit Icon of Created Project inside Contract Management QA for Creation on Contract Management");
		System.out.println("---------------------------------------------------");
	}

	public void click_On_send_back_to_analyst_queue_of_Created_Project_CMMC() {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(sendBackToContractAnalystBtn)).click();
		System.out
				.println("Clicked on send back to anaylst Queue Button of Creation on Contract Management Maintenance Project");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnContractAnalystBtnOfContractManagement() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking contract analyst");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(contractAnalystBtn)).click();

		System.out.println("Clicked on conract QA button on Contract Management maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void click_On_Edit_Icon_of_Created_Project_insideContract_Analyst_CMMC() {
		elementutil.explicitWait(editIconInsideContractQA, driver);
		elementutil.Click(driver.findElement(editIconInsideContractQA));
		System.out
				.println("Clicked on Edit Icon of Created Project inside Contract Management QA for Creation on Contract Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnWirhdrawBtnOfMaintProjCreation_CMMC() {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(withdrawBtnOfMaintProjCreation)).click();

		System.out.println("Clicked on Withdraw Button for Maintaianance Project Creation on Contract Management");
		System.out.println("---------------------------------------------------");
	}

	public void enterWithdrawalCommenttOFContractManagement_CMMC() {
		elementutil.explicitWait(enterCommentsBoxInContractMngmntMaintproj, driver);
		elementutil.Input(driver.findElement(enterCommentsBoxInContractMngmntMaintproj),
				"Testing Project Creation Inside Contract Managament By Deepak Mahapatra");
		System.out.println("Entered Text in Comment box for withdrwal of Maint project of Contract Management ");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnOkBtnOfWithdrawalOfContractmanagement_CMMC() throws Exception {
		elementutil.explicitWait(okBtnOfwithDrawProject_CMMC, driver);
		elementutil.explicitWaitUntilElementIsClickable(okBtnOfwithDrawProject_CMMC, driver);

		elementutil.javaScrptClick(driver, driver.findElement(okBtnOfwithDrawProject_CMMC));
		Thread.sleep(5000);
		System.out
				.println("Clicked on ok button for Withdrawal of Maintaianance Project Creation on Contract Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnRateManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++  Rate Managemnt");
		elementutil.explicitWait(RateManagementBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(RateManagementBtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Rate Management");
	}

	public void clickOnQueuesofRateManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(QueuesOfRateManagementBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(QueuesOfRateManagementBtn));

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Queues of Rate Management");
	}

	public List<String> getQueuesItemListUnderRateManagement() {
		List<String> ItemsUnderQueueList = new ArrayList<String>();
		elementutil.explicitWait(ItemsUnderQueuesOfRateManagement, driver);
		// driver.switchTo().frame(0);
		List<WebElement> itemsUnderQueue = driver.findElements(ItemsUnderQueuesOfRateManagement);
		for (WebElement e : itemsUnderQueue) {
			String text = e.getText();
			ItemsUnderQueueList.add(text);
			System.out.println("Items under Queues of Rate Management :" + text);
		}
		return ItemsUnderQueueList;
	}

	public void clickOnMaintenanceOfRateManagementLink() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		elementutil.explicitWait(MaintenanceOfRateManagementBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(MaintenanceOfRateManagementBtn));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Maintenance of Rate Management");
	}

	public List<String> getMaintenanceItemListUnderRateManagement() {
		List<String> ItemsUnderMaintenanceList = new ArrayList<String>();
		// driver.switchTo().frame(0);
		elementutil.explicitWait(ItemsUnderMaintenanceOfRateManagement, driver);
		List<WebElement> itemsUnderMaintenance = driver.findElements(ItemsUnderMaintenanceOfRateManagement);
		for (WebElement e : itemsUnderMaintenance) {
			String text = e.getText();
			ItemsUnderMaintenanceList.add(text);
			System.out.println("Items under Maintenance of Rate Management :" + text);
		}
		return ItemsUnderMaintenanceList;
	}

	public void clickOnManagePharmacyListBtnOfRateManagement_RMC() {
		elementutil.explicitWaitUntilElementIsClickable(managePharmacyListBtn, driver);
		elementutil.javaScrptClick(driver, driver.findElement(managePharmacyListBtn));
		System.out.println("Clicked on Manage Pharmacy List button in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void enter_Pharmacy_List_Name_Into_PLN_Box_RMC() {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		elementutil.explicitWait(pharmacyNameListTextBox, driver);
	}

	public void enter_Description_Name_Into_PLN_Box_RMC() {
		elementutil.explicitWait(descriptionBoxOfPharmacyListCreation, driver);
	}

	public void clickOnCreateProjectBtn_PharmacyList_RMC() {
		elementutil.explicitWaitUntilElementIsClickable(creteBtn_PLC_RMC, driver);
		elementutil.javaScrptClick(driver, driver.findElement(creteBtn_PLC_RMC));
		System.out.println("Clicked on Create Project button While Creating Pharmacy List in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnCreateProjectLink_RMC() throws Exception {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");

		Thread.sleep(3000);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(createProjectBtnInRteMngmnt));
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Create Project Button while creating a pharmacy List in Rate Management");
	}

	public void enter_HQList_While_Creating_Pharmacy_List_Box_RMC() {
		elementutil.explicitWait(HqListCodetextBox_RMC, driver);
	}

	public void enter_NABP_No_RMC() {
		elementutil.explicitWait(NABP_NO_Click, driver);

	}

	public void clickOnAddBtnWhileCreatingPL_RMC() throws Exception {

		wait = new WebDriverWait(driver, 10);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(addButtonOn_RMC)).click();

		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Add button in NABP while creating a pharmacy List in Rate Management");
	}

	public void clickOnSendToConfigurationBtnOfRateManagement_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.explicitWaitUntilElementIsClickable(sendToConfigQA_RMC, driver);
		elementutil.javaScrptClick(driver, driver.findElement(sendToConfigQA_RMC));
		System.out
				.println("Clicked on Send to Configuration QA button for creation of Pharmacy List in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnConfigurationQABtnOf_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on Configuration QA Button of Rate Management");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(configruationQaBtn_RMC)).click();
		System.out.println("Clicked on Configuration QA button on Rate Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickedOnEditIconOnConfgQC_RMC() throws Exception {
		Thread.sleep(7000);
		elementutil.explicitWait(projectDescription_RMC_InCongQC, driver);
		elementutil.Input(driver.findElement(projectDescription_RMC_InCongQC),
				"Test Creation Of Pharmacy List In Rate Management");
		System.out.println("Entered Text in Serach box of Project Description Of Rate Management ");
		elementutil.explicitWait(editIconOn_Cong_QA_RMC, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconOn_Cong_QA_RMC)).click();
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		System.out.println("Clicked on Edit Icon of Created Project inside Config QA Of Rate Management");
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
	}

	public void clickedOnSendToConfigAnalyst_RMC() throws Exception {
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(sendBackToConfigAnalystBtn_RMC)).click();
		System.out.println("Clicked on Configuration Analyst Button Of Rate Management while creating pharmacy List");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnConfigurationAnalyst_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out
				.println("Switched Frame to Parent Tab for clicking on Configuration Analyst Button of Rate Management");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(configurationAnalystBtn_RMC)).click();
		System.out.println("Clicked on Configuration Analyst button on Rate Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnWithDrawConfigurationAnalyst_RMC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(withdrawBtn_ConfigAnalyst_RMC)).click();
		System.out.println("Clicked on Configuration Analyst button on Rate Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void enterWithdrawalCommentOnConfigAnalyst_RMC() {
		elementutil.Input(driver.findElement(withdraw_cmnt_Box_RMC),
				"Automation Testing of withdrawal pharmacy list creation project from On Hold");
		System.out
				.println("User entered the message into the message box after clicking on withwraw of Configuration Analyst on Rate Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnOkBtnOfWithDrawConfigurationAnalyst_RMC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(okBtn_RMC)).click();
		System.out
				.println("Clicked on Ok Button after clicking on withwraw of Configuration Analyst on Rate Management project creationn");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnManageBuildingblocksBtnOfRateManagement_RMC() {
		elementutil.explicitWaitUntilElementIsClickable(manageBuildingBlockBtn_RMC, driver);
		elementutil.javaScrptClick(driver, driver.findElement(manageBuildingBlockBtn_RMC));
		System.out.println("Clicked on Manage Building Block button in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void enter_Description_Name_Into_Description_Box_While_Creating_BB_RMC() {

		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		elementutil.explicitWait(descriptionBoxOfPharmacyListCreation, driver);

	}

	public void enter_BBName_RMC() {
		elementutil.explicitWait(clickOnBBName_RMC, driver);

	}

	public void selectRfromServiceTypeDropDown_RMC() throws Exception {
		elementutil.explicitWait(ServiceType_Drop_Down_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, ServiceType_Drop_Down_RMC);
		elementutil.ClickEvent(driver, ServiceType_Drop_Down_RMC1);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		System.out
				.println("Selected Dropdown on Service type Add while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void selectABBfromABB_CBB_DropDown_RMC() throws Exception {
		elementutil.explicitWait(ABB_Drop_Down_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, ABB_Drop_Down_RMC);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		System.out.println("Selected Dropdown on ABB/CBB while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void selectAggregate_From_Building_Block_Type_DropDown_RMC() throws Exception {
		elementutil.explicitWait(BuildingBlockType_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, BuildingBlockType_RMC);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		System.out
				.println("Selected Aggregate from  Building Block while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void selectCommercial_From_LOb_DropDown_RMC() throws Exception {
		elementutil.explicitWait(LOB_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, LOB_RMC);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		Thread.sleep(3000);
		System.out
				.println("Selected Commercial from  LOB drpdown while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
		WebElement h = driver.findElement(By.id("jqxScrollThumbhorizontalScrollBaraddBBGrid"));

		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(horizontal_Scrol_Bar)).click();
		Actions move = new Actions(driver);
		move.moveToElement(driver.findElement(horizontal_Scrol_Bar)).clickAndHold();
		move.moveByOffset(140, 0);
		move.release();
		move.perform();
	}

	public void selectNCPDP_From_PharmacyType_DropDown_RMC() throws Exception {
		elementutil.explicitWait(pharmacy_Type_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, pharmacy_Type_RMC);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		Thread.sleep(3000);
		System.out
				.println("Selected  NCPDP Dropdown from Pharmacy Type while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void enterPharmacyType_RMC() throws Exception {
		elementutil.explicitWait(pharmacy_identifier_Click_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, pharmacy_identifier_Click_RMC);
		Thread.sleep(2000);
		System.out
				.println("Clicked on Pharmacy Type Input Box while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void clickOutside_RMC() throws Exception {
		wait = new WebDriverWait(driver, 10);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(outsideClick_BB_RMC)).click();
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked outside after entering the details to add while creating a Building Block in Rate Management");
	}

	public void clickOnAddBtnAddingBuildingBlock_RMC() throws Exception {
		wait = new WebDriverWait(driver, 10);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(Add_BB_Btn_RMC)).click();
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add button in Building Blocks while creating a Building Block in Rate Management");
	}

	public void clickOnSaveProgressButton_RMC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(saveButton_BB_Creation_RMC)).click();

		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Save progress button while creating a Building Block in Rate Management");
	}

	public void clickOnSendToPricingAnalystButton_RMC() {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(sendToPricingApproverBtn_BB_RMC));
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on send To pricing Analyst button while creating a Building Block in Rate Management");
	}

	public void clickOnPricingAnalystApprover_RMC() throws Exception {
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out
				.println("Switched Frame to Parent Tab for clicking on Configuration Analyst Button of Rate Management");
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(pricingAnalystApproverBtn)).click();

		System.out.println("Clicked on Pricing Analyst Approver button on Rate Management project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickedOnEditIconOnPricingAnalystApprover_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.explicitWait(projectDescription_RMC_InCongQC, driver);
		elementutil.Input(driver.findElement(projectDescription_RMC_InCongQC), "Automation of Creation of BB");
		System.out
				.println("Entered Text in Serach box of Project Description Of Rate Management In Pricing Analyst Approver");
		elementutil.explicitWait(editIconOn_Pricing_Analyst_Approver_RMC, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconOn_Pricing_Analyst_Approver_RMC)).click();
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		System.out.println("Clicked on Edit Icon of Created Project inside Pricing Anayst Approver Of Rate Management");
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
	}

	public void clickOnSendBackToPricingAnalystButton_RMC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(sendToPricingAnalystBtn_RMC)).click();

		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Send To Pricng analyst button while creating a Building Block in Rate Management");
	}

	public void clickOnPricingAnalyst_RMC() throws Exception {
		// Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on Pricing Analyst Button of Rate Management");
		elementutil.explicitWait(pricingAnalystButton_RMC, driver);
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(pricingAnalystButton_RMC)).click();

		Thread.sleep(3000);
		System.out.println("Clicked On Pricing Analyst button on Rate Management for BB creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnManageCNPBtnOfRateManagement_RMC() {
		elementutil.explicitWaitUntilElementIsClickable(manageCNPBtn_RMC, driver);
		elementutil.javaScrptClick(driver, driver.findElement(manageCNPBtn_RMC));
		System.out.println("Clicked on Manage CNP button in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void selecthqList_from_request_typeDropDown() {
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		elementutil.explicitWait(hqListSelectionBox_RMC, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(hqListSelectionBox_RMC), "HLN");
		System.out
				.println("Selected Dropdown hq List from drop down while creatimg CNP in Rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void enter_ProjectName_Into_Search_Box_CNP_Creation_in_RMC() {
		elementutil.explicitWait(projectname_CNP_Creation_RMC, driver);

	}

	public void clickOnSearchBtnInCNPCreation_RMC() {
		elementutil.explicitWaitUntilElementIsClickable(searchBtn_CNP_Creation_RMC, driver);
		elementutil.javaScrptClick(driver, driver.findElement(searchBtn_CNP_Creation_RMC));
		System.out.println("Clicked on Search Button  while entering details for CNP creation in Rate Management");
		System.out.println("---------------------------------------------------");
	}

	public void clickOneyeBtntoViewCNP_RMC() throws Exception {
		elementutil.explicitWait(eyeBtnInCNPCreation_RMC, driver);
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(eyeBtnInCNPCreation_RMC))).click();
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on eye button inside Rate Management for CNP creation");
	}

	public void clickOnCreateProjectButto_CNP_RMC() {
		elementutil.explicitWait(CreateProjectBtnInCNPCreation_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(CreateProjectBtnInCNPCreation_RMC)))
				.click();
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Create Project button inside Rate Management for CNP creation");
	}

	public void clickOnRetailOnServiceTypeSelection_CNP_RMC() {
		elementutil.explicitWait(servicTypeSelection_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(servicTypeSelection_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out.println("Selected retail from service Type inside Rate Management for CNP creation");
	}

	public void enter_Description_Into_text_Box_CNP_Creation_in_RMC() {
		elementutil.explicitWait(description_CNP_RMC, driver);
	}

	public void clickOnContinue_CNP_RMC() {
		elementutil.explicitWait(continueBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(continueBtn_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on continue button inside Rate Management for CNP creation");
	}

	public void selectAggregateFromBBTypeDropDown_RMC() {
		elementutil.explicitWait(BBTypeDropDown_CNP_RMC, driver);
		ElementUtil.dropDownSelectByValue(driver.findElement(BBTypeDropDown_CNP_RMC), "AGGREGATE");
		System.out
				.println("Selected Dropdown Aggregate from  BB Type while creatimg CNP in Rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void selectNameFromBBNameDropDown_RMC() throws Exception {
		elementutil.explicitWait(BbNameDropDown_CNP_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, BbNameDropDown_CNP_RMC);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		System.out.println("Selected Dropdown on BB Name while creating CNP In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnAddBtn_CNP_RMC() {
		elementutil.explicitWait(addBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(addBtn_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add button after selecting BB Type and BB Name inside Rate Management for CNP creation");
	}

	public void enterBrandDiscount_CNP_RMC() throws Exception {
		elementutil.explicitWait(brandDiscountClick_CNP_RMC, driver);
		Thread.sleep(3000);
		elementutil.ClickEvent(driver, brandDiscountClick_CNP_RMC);
		Thread.sleep(2000);
		System.out
				.println("Clicked on Pharmacy Type Input Box while creating BB In rate Management--------------------");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnSaveProgressOfRateManagement_RMC() {
		elementutil.explicitWait(saveProgressBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(saveProgressBtn_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out.println("Clicked on Save button after adding  BB Details inside Rate Management for CNP creation");
	}

	public void clickOnSendToPricingApproverBtn_CNP_RMC() {
		elementutil.explicitWait(sendToPricingApproverBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(sendToPricingApproverBtn_CNP_RMC)))
				.click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on send To PricingApprover Button after adding  BB Details inside Rate Management for CNP creation");
	}

	public void clickOnPricingAnlystApprover_CNP_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on Pricing Analyst Approver");
		elementutil.explicitWait(PricingApproverAnalystBtn_CNP_RMC, driver);
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(PricingApproverAnalystBtn_CNP_RMC)).click();
		System.out
				.println("Clicked on Pricing Analyst Approver button on Rate Management for CNP maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickedOnEditIconOnPricingAnalystApprover_CNP_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.explicitWait(projectDescription_RMC_InCongQC, driver);
		elementutil.Input(driver.findElement(projectDescription_RMC_InCongQC),
				"Testing Creating CNP Maintenance Project");
		System.out
				.println("Entered Text in Serach box of Project Description Of Rate Management In Pricing Analyst Approver");
		elementutil.explicitWait(editIconInPricingAnalystPrrover_CNP_RMC, driver);
		Thread.sleep(3000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(editIconInPricingAnalystPrrover_CNP_RMC)).click();
		elementutil.switchToNewTab(driver);
		driver.manage().window().maximize();
		System.out
				.println("Clicked on Edit Icon of Created Project inside Pricing Anayst Approver Of Rate Management for CNP Creation");
		Thread.sleep(4000);
		System.out.println("---------------------------------------------------");
	}

	public void clickOnSendToConfigurationAnalystApproverBtn_CNP_RMC() {
		elementutil.explicitWait(sendToConfigAnalystBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(sendToConfigAnalystBtn_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on send To Configuration Analyst Button after clicking on eidt in pricing analyst approver inside Rate Management for CNP creation");
	}

	public void clickOnConfigurationAnalyst_Btn_CNP_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on Pricing Analyst Approver");
		elementutil.explicitWait(configurationAnalystBtn_CNP_RMC, driver);
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(configurationAnalystBtn_CNP_RMC)).click();
		System.out
				.println("Clicked on Configuration Analyst button on Rate Management for CNP maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnexpandAggregateBtn_CNP_RMC() {
		elementutil.explicitWait(expandAggregateBtn_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(expandAggregateBtn_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on expand Aggregate Button after entering priority inside Rate Management for CNP creation");
	}

	public void clickOnAddNetworkCodeBtn_CNP_RMC() {
		elementutil.explicitWait(addNetwrokCode, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(addNetwrokCode))).click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on Add Network Button after entering Network Code inside Rate Management for CNP creation");
	}

	public void clickOnsendToConfigurationAnalyst_CNP_RMC() {
		elementutil.explicitWait(sendToConfigQA_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(sendToConfigQA_CNP_RMC))).click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on send to config qa Button after entering Network Code inside Rate Management for CNP creation");
	}

	public void clickOnConfigurationQA_Btn_CNP_RMC() throws Exception {
		Thread.sleep(3000);
		elementutil.switchToParentTab(driver);
		driver.switchTo().frame(0);
		System.out.println("Switched Frame to Parent Tab for clicking on Pricing Analyst Approver");
		elementutil.explicitWait(configQA_RMC, driver);
		Thread.sleep(4000);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(configQA_RMC)).click();
		System.out
				.println("Clicked on Configuration QA button on Rate Management for CNP maintenance project creation");
		System.out.println("---------------------------------------------------");
	}

	public void clickOnsendToConfigAnalyst_CNP_RMC() {
		elementutil.explicitWait(sendBackToConfigurationAnalyst_CNP_RMC, driver);
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(sendBackToConfigurationAnalyst_CNP_RMC)))
				.click();
		System.out.println("---------------------------------------------------");
		System.out
				.println("Clicked on send to config Analyst Button after  Code inside Rate Management for CNP creation");
	}

	public void clickOnWithDrawConfigurationAnalyst_CNP_RMC() {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(withDrawBtn_CNP_RMC)).click();
		System.out.println("Clicked on withdraw button on Rate Management project creation in config analyst");
		System.out.println("---------------------------------------------------");
	}

}
