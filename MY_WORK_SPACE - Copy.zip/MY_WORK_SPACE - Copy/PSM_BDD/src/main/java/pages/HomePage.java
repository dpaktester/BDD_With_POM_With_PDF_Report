/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */

package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import factory.DriverFactory;

public class HomePage {
	private WebDriver driver;
	
	private By HomeFields = By.xpath("//*[@class='panel-heading']");
	private By QueueFields=By.xpath("//*[@class='text-left']//span");
	private By MaintandDashBoardFields=By.xpath("//*[@class='text-left']");

	public HomePage(WebDriver driver) {
		this.driver = driver;

	}

	public int getCountOfHomePage() {
		//driver.switchTo().frame(0);
		return driver.findElements(HomeFields).size();
	}

	public List<String> getHomePageItemList() {
		List<String> homePageList = new ArrayList<String>();
		//driver.switchTo().frame(0);
		List<WebElement> itemsOfHomePage = driver.findElements(HomeFields);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsOfHomePage) {
			String text = e.getText();
			//System.out.println("Items of Home Page of PSM" + text);
			homePageList.add(text);
			System.out.println("Items of Home Page of PSM " + text);
		}
		return homePageList;
	}
	
	public List<String> getQueueItemList() {
		List<String> QueueItemList = new ArrayList<String>();
		//driver.switchTo().frame(0);
		List<WebElement> itemsOfQueue = driver.findElements(QueueFields);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsOfQueue) {
			String text = e.getText();
			//System.out.println("Items of Home Page of PSM" + text);
			QueueItemList.add(text);
			//System.out.println("Items Under Queues of PSM " + text);
		}
		return QueueItemList;
	}
	public List<String> getMaintenanceItemList() {
		List<String> maintenenaceItemList = new ArrayList<String>();
		//driver.switchTo().frame(0);
		List<WebElement> itemsOfMaintenance = driver.findElements(MaintandDashBoardFields);
		// for(int i=0;i<=itemsOfHomePage;i++){
		for (WebElement e : itemsOfMaintenance) {
			String text = e.getText();
			maintenenaceItemList.add(text);
			//System.out.println("Items under Maintenance of PSM " + text);
		}
		return maintenenaceItemList;
	}

}
