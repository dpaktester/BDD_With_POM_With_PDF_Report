/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */


package utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.Keys;

import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ElementUtil {
	public static WebDriver driver;
	Properties prop;
	private ConfigReader configReader;
	public static Select select;
	static String parentWindow ;
	public static int ranNo;

	public void Click(WebElement element) {
		try {
			element.click();
		} catch (WebDriverException e) {

			e.printStackTrace();
		}

	}

	public void javaScrptClick1(WebDriver driver, WebElement element) {
		try {
			element.click();
		} catch (WebDriverException e) {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			e.printStackTrace();
		}

	}

	public void javaScrptClick(WebDriver driver, WebElement element) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);

	}

	public void contextClick(WebDriver driver, By element) {
		// Actions build = new Actions(driver);
		Actions action = new Actions(driver);
		WebElement link = driver.findElement(element);

		action.contextClick(link).perform();
		// build.MoveToElement(driver.findElement(element)).ContextClick().Build().Perform();
	}

	public void contextClickandClickback(WebDriver driver, By element) throws Exception {
		Actions action = new Actions(driver);
		WebElement link = driver.findElement(element);
		// action.contextClick(link).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.RETURN).build().perform();
		action.contextClick(link).perform();
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	public void doubleClick(WebDriver driver, By element) {
		Actions acttion = new Actions(driver);
		WebElement ele = driver.findElement(element);
		acttion.doubleClick(ele).perform();
	}

	public void ClickEvent(WebDriver driver, By element) {
		Actions action = new Actions(driver);
		Actions action1 = new Actions(driver);
		WebElement ele = driver.findElement(element);
		action1 = action.moveToElement(ele).doubleClick();
		action1.click().build().perform();
	}
	
	public void waitUntillelementLoadsandClick(By element) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	}

	public void clickUpp() throws Exception {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
		robot.keyPress(KeyEvent.VK_UP);
		robot.keyRelease(KeyEvent.VK_UP);
	}
	public void clickOnRefresh() throws Exception {
		Robot robot= new Robot();
		robot.keyPress(KeyEvent.VK_F5);
		robot.keyRelease(KeyEvent.VK_F5);
		robot.keyPress(KeyEvent.VK_F5);
		robot.keyRelease(KeyEvent.VK_F5);
		robot.keyPress(KeyEvent.VK_F5);
		robot.keyRelease(KeyEvent.VK_F5);
		robot.keyPress(KeyEvent.VK_F5);
		robot.keyRelease(KeyEvent.VK_F5);
		robot.keyPress(KeyEvent.VK_F5);
		robot.keyRelease(KeyEvent.VK_F5);
	}

	public void ClearAndInput(WebElement element, String value) {
		try {
			element.clear();
			element.sendKeys(value);
		} catch (WebDriverException e) {
			e.printStackTrace();

		}

	}

	public void Input(WebElement element, String value) {
		try {
			element.sendKeys(value);
		} catch (WebDriverException e) {
			e.printStackTrace();
		}

	}

	public String encryptPassword(String password) {
		configReader = new ConfigReader();
		prop = configReader.init_prop();
		byte[] encodedString = Base64.encodeBase64(prop.getProperty("password_personal").getBytes());
		return password;

	}

	// It's called in Driver Factory because it will be set once
	public void implicitWait() {
		driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);
	}

	public void explicitWait(By element, WebDriver driver) {

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
	}

	public void explicitWaitUntilElementIsClickable(By element, WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public void waitForDomLoad(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));

	}

	// select the dropdown using "select by visible text"
	public static void dropDownSelectByText(WebElement webElement, String VisibleText) {
		Select selObj = new Select(webElement);
		selObj.selectByVisibleText(VisibleText);
	}

	// select the dropdown using "select by index"
	public static void dropDownSelectByIndex(WebElement webElement, int IndexValue) {
		Select selObj = new Select(webElement);
		selObj.selectByIndex(IndexValue);
	}

	// select the dropdown using "select by value"
	public static void dropDownSelectByValue(WebElement webElement, String Value) {
		Select selObj = new Select(webElement);
		selObj.selectByValue(Value);
	}

	// To Get a Drop-Down Value selected from UI
	public static List GetSelectedDropDown(WebElement element) {
		select = new Select(element);
		return select.getOptions();
	}

	// To Get a Drop-Down One by one Value selected from UI
	public static List GetSelectedDropDownOneByOne(By element, WebDriver driver) {

		List options = new ArrayList<String>();
		for (WebElement option : new Select(driver.findElement(element)).getOptions()) {
			String txt = option.getText();
			if (option.getAttribute("value") != "")
				options.add(option.getText());
			// txt.toString().split(",");
		}
		return options;
	}

	// String oldTab = driver.getWindowHandle();
	// public static void switchingToNewTabUsingid(WebDriver
	// driver,WebDriverWait wait,String id,String oldTab)
	// WebDriverWait wait = new WebDriverWait(driver, 10);
	public static void switchingToNewTabUsingid(WebDriver driver, String id) {

		// wait.until(ExpectedConditions.elementToBeClickable(By.id(id)));
		driver.findElement(By.id(id)).click();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		// newTab.remove(oldTab);
		driver.switchTo().window(newTab.get(1));
	}

	public static void switchToNewTab(WebDriver driver) {
		 parentWindow = driver.getWindowHandle();
		System.out.println("Parent Window Is :: " + parentWindow);
		Set<String> allWindows = driver.getWindowHandles();
		ArrayList<String> tabs = new ArrayList(allWindows);
		driver.switchTo().window(tabs.get(1));
	}
	
	public static void switchToParentTab(WebDriver driver) {
		driver.switchTo().window(parentWindow);
	}

	public void scrollDown() throws Exception {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
	}
	
	public void  gotoBottom(){
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}

	public void scrollUp() throws Exception {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_UP);
		robot.keyRelease(KeyEvent.VK_PAGE_UP);
	}

	public void startdate(WebElement element) throws Exception {
		ElementUtil elementutil= new ElementUtil();
		LocalDate startDate = LocalDate.now();
		System.out.println("startDate__ "+ startDate);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
		String startDate1 = formatter.format(startDate);
		Thread.sleep(5000);
		elementutil.javaScrptClick(driver, element);
		Thread.sleep(5000);
		//element.click();
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DELETE);
		robot.keyRelease(KeyEvent.VK_DELETE);
		//element.sendKeys(Keys.DELETE);
		//element.sendKeys(Keys.DELETE);
		String[] arrOfDate = startDate1.split("/");
		for (String a : arrOfDate) {
			element.sendKeys(a);
		}
	}

	public void enddate(WebElement element) {
		LocalDate endDate = LocalDate.now().plusDays(666);
		System.out.println("endDate__ "+endDate);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
		String endDate1 = formatter.format(endDate);
		element.sendKeys(Keys.DELETE);
		element.sendKeys(Keys.DELETE);
		String[] arrOfDate = endDate1.split("/");
		for (String a : arrOfDate) {
			element.sendKeys(a);
		}
	}
	 public void RandomNumber(){
		Random rand = new Random();
		int n = rand.nextInt(50);
		ranNo= n += 1;
	 }
}
