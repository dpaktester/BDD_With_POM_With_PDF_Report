/*
 * 
 * 
 * @Author : Deepak Mahapatra
 * 
 */

package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
	public static Properties prop;
	/** This method is used to load the properties from the properties file*/
	public Properties init_prop(){
		prop = new Properties();
		try {
			//FileInputStream ip = new FileInputStream("D:\\MY_WORK_SPACE\\PSM_BDD\\src\\test\\resources\\config\\config.properties");
			FileInputStream ip = new FileInputStream("/PSM_BDD/src/test/resources/config/config.properties");
			
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop;
	}

}
